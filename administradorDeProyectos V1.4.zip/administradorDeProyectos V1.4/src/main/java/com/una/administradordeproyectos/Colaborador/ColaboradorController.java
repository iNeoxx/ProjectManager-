/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Colaborador;

import com.una.administradordeproyectos.Tareas.TareaEntity;
import java.util.ArrayList;
import java.util.Collection;

/**
 *
 * @author antho
 */
public class ColaboradorController implements ColaboradorInterface{

    @Override
    public String crear(String[] data) {//Funcion crear recibe por parametro un array de datos de colaborador
        String respuesta = "Ya existe un colaborador con esa cedula";
        if(!ColaboradorContainer.exist(data[0])){//Se verifica que no exista un colaborador con esa cedula
            ColaboradorEntity nColaborador = new ColaboradorEntity(data);//se crea el colaborador
            if(ColaboradorContainer.add(nColaborador)){//Se llama la funcion add del contenedor y se manda por parametro para almacenar
                respuesta = "Colaborador agregado correctamente";
            }else{//Hubo un error
                respuesta = "Error al agregar al contenedor";
            }
        }
        return respuesta;
    }

    @Override
    public String modificar(String[] data){//recibe los nuevos datos
        String answer = "No existen ningun colaborador con esa cedula";
        if(ColaboradorContainer.exist(data[0])){//verifica que exista ese colaborador para reemplazarlo
            ColaboradorEntity newColaborador = new ColaboradorEntity(data);//se crea
            if(ColaboradorContainer.update(newColaborador, data[0])){//se manda el colaborador nuevo junto a la cedula
                answer = "Colaborador reemplazado correctamente";
            }else{
                answer = "Error al reemplazar el colabolaborador";
            }
        }
        return answer;
    }

    @Override
    public String[] find(String cedula) {
        ColaboradorEntity colaborador;
        if(ColaboradorContainer.exist(cedula)){
            colaborador = ColaboradorContainer.find(cedula);
            if(colaborador.getEstado()){
                String []data = {"Cedula: "+colaborador.getCedula(), "Nombre: "+colaborador.getNombre()+" "+colaborador.getApellidos(), "Telefono: "+colaborador.getTelefono(), "Correo: "+colaborador.getEmail(), "Especialidad: "+colaborador.getEspecialidad(), "Estado: ACTIVO"};
                return data;
            }else{
                String []data = {"Cedula: "+colaborador.getCedula(), "Nombre: "+colaborador.getNombre()+" "+colaborador.getApellidos(), "Telefono: "+colaborador.getTelefono(), "Correo: "+colaborador.getEmail(), "Especialidad: "+colaborador.getEspecialidad(), "Estado: INACTIVO"};
                return data;
            }
        }
        return null;
    }

    @Override
    public String eliminar(String cedula) {
        String respuesta = "No existe ningun colaborador con esa cedula";
        if(ColaboradorContainer.exist(cedula)){//primero se verifica que exista el colaborador
             if(ColaboradorContainer.delete(cedula)){//si existe lo elimina
                respuesta = "Colaborador eliminado correctamente";
            }else{//si no se elimina debe ser por algun error
                respuesta = "Error al eliminar al colaborador";
            }
        }
        
        return respuesta;
    }

    @Override
    public String[] mostrarTodos() {
        if(ColaboradorContainer.getAll()!= null){
            Collection<ColaboradorEntity> colaboradores = ColaboradorContainer.getAll();
            String []data = new String[colaboradores.size()];
            int i = 0;
            for(Object c:colaboradores){
                 ColaboradorEntity colaborador = (ColaboradorEntity)c;
                 if(colaborador.getEstado()==false){
                    data[i] = "Nombre: "+colaborador.getNombre()+" "+colaborador.getApellidos()+" Cedula: "+colaborador.getCedula()+" Estado: INACTIVO";
                 }else{
                    data[i] = "Nombre: "+colaborador.getNombre()+" "+colaborador.getApellidos()+" Cedula: "+colaborador.getCedula()+" Estado: ACTIVO";
                 }
                    i++;
            }
            return data;
        }
        return null;
    }
    
    @Override
    public String[] mostrarTareasDeUnColaborador(String cedula){//se recibe la cedula del colaborador
        ColaboradorEntity colaborador = ColaboradorContainer.find(cedula); 
        ArrayList cosa = colaborador.getTareas();
        if(colaborador != null){
            String data[] = new String[cosa.size()];
            int i = 0;
            for(Object c: cosa){
                TareaEntity tarea = (TareaEntity)c; 
                data[i] = "Identificador: " + tarea.getIdentificador() + "| Descripcion: " + tarea.getDescripcion() + "| Colaborador: " + tarea.getColaborador().getNombre() + " " + tarea.getColaborador().getApellidos() + "| Recursos: "+tarea.getRecursos() +
                          "| Fecha Inicio: " + tarea.getFechaInicio().getDate() + "/" + (tarea.getFechaInicio().getMonth() + 1) + "/" + (tarea.getFechaInicio().getYear() + 1900) + "| Fecha Cierre: " + tarea.getFechaCierre().getDate() + "/" + (tarea.getFechaCierre().getMonth() + 1) + "/" + (tarea.getFechaCierre().getYear() + 1900);
                i++;
            }
            return data;
        }
        return null; 
    }
    @Override
    public boolean eliminarTarea(String cedula, String identificador){//Elimina una tara del arrayList de tareas de colaborador
        ColaboradorEntity colaborador = ColaboradorContainer.find(cedula);//Se busca el colaborador primero
        if(colaborador != null){//se verifica que exista
            ArrayList tareas = colaborador.getTareas();//Se extrae el arrayist entero
            int i = 0;
            for(Object c: tareas){//Se recorre
                TareaEntity tarea = (TareaEntity)c;
                if(tarea.getIdentificador() == identificador){//Si lo encuentra entra
                    colaborador.getTareas().get(i).setColaborador(null);//Se extrae la tarea y el atributo colaborador se le cambia a null
                    colaborador.getTareas().remove(i);//se remuere del atributo arraylist<TareaEntity> una tarea especifica
                    return true;
                }
            }
        }
        return false;
    }
    
}
