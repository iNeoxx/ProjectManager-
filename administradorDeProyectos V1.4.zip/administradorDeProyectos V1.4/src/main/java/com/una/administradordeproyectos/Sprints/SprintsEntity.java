/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Sprints;

import com.una.administradordeproyectos.Proyecto.ProyectoEntity;
import com.una.administradordeproyectos.Tareas.TareaEntity;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author antho
 */
public class SprintsEntity {
    private String identificador;
    private Date fechaInicio;
    private Date fechaCierre;
    private ArrayList<TareaEntity> tareas;
    private ProyectoEntity proyecto;
    
    public SprintsEntity(String identificador, Date[] fechas){
        this.identificador = identificador; 
        this.fechaInicio = fechas[0]; 
        this.fechaCierre = fechas[1];
        this.tareas = new ArrayList();
        
    }

    /**
     * @return the identificador
     */
    public String getIdentificador() {
        return identificador;
    }

    /**
     * @param identificador the identificador to set
     */
    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    /**
     * @return the fechaInicio
     */
    public Date getFechaInicio() {
        return fechaInicio;
    }

    /**
     * @param fechaInicio the fechaInicio to set
     */
    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    /**
     * @return the fechaCierre
     */
    public Date getFechaCierre() {
        return fechaCierre;
    }

    /**
     * @param fechaCierre the fechaCierre to set
     */
    public void setFechaCierre(Date fechaCierre) {
        this.fechaCierre = fechaCierre;
    }

    /**
     * @return the tareas
     */
    public ArrayList<TareaEntity> getTareas() {
        return tareas;
    }

    /**
     * @param tarea the tareas to set
     */
    public void setTarea(TareaEntity tarea) {
        this.tareas.add(tarea);
    }

    /**
     * @return the proyecto
     */
    public ProyectoEntity getProyecto() {
        return proyecto;
    }

    /**
     * @param proyecto the proyecto to set
     */
    public void setProyecto(ProyectoEntity proyecto) {
        this.proyecto = proyecto;
    }
    
}
