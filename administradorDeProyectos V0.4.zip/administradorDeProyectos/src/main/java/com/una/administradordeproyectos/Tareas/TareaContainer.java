/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Tareas;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author antho
 */
public class TareaContainer {
    private static Map<String,TareaEntity> eTarea = new HashMap<String,TareaEntity>();
     //KEY es identificador de Tarea
}
