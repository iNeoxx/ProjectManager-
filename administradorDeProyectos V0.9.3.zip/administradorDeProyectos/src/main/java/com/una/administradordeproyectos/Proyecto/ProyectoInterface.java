/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Proyecto;

import java.text.ParseException;

/**
 *
 * @author antho
 */
public interface ProyectoInterface {
    public String crear(String []data, String identificador)throws ParseException;
    public String modificar();
    public String[] buscar(String identificador);
    public String eliminar(String identificador);
    public String[] mostrarTodos();
    public String generarIdentificador(String p, int numero);
}