/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Proyecto;

import java.util.Collection;
import java.util.Map;
import java.util.HashMap;
/**
 *
 * @author antho
 */
public class ProyectoContainer {
    //Key = identificador del proyecto
    private static Map<String,ProyectoEntity> cProyecto = new HashMap<String,ProyectoEntity>();
    
    public static boolean agregar(ProyectoEntity proyecto){
        if(!cProyecto.containsKey(proyecto.getIdentificador())){
            cProyecto.put(proyecto.getIdentificador(), proyecto);
            cProyecto.values().iterator();
            return true;
        }
        return false;
    }
    public static boolean existe(String identificador){
        if(cProyecto.containsKey(identificador)){
             return true;
         }
        return false;
    }
    public static ProyectoEntity buscar(String identificador){
        if(cProyecto.containsKey(identificador)){
            ProyectoEntity proyecto = cProyecto.get(identificador);
            return proyecto;
        }
        return null;
    }
    public static boolean actualizar(){
        return false;
    }
    public static boolean eliminar(String identificador){
        if(cProyecto.containsKey(identificador)){
            cProyecto.remove(identificador);
            return true;
        }
        return false;
    }
    public static Collection<ProyectoEntity> mostrarTodos(){
        Collection<ProyectoEntity> proyecto = cProyecto.values();
        if(!cProyecto.isEmpty()){
            return proyecto;
        }
        return null;
    }
    
}
