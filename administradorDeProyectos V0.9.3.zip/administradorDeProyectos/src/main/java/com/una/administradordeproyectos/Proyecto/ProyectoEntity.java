/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Proyecto;

import com.una.administradordeproyectos.Sprints.SprintsEntity;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author antho
 */
public class ProyectoEntity {
    private String identificador;
    private String nombreProyecto;
    private Date fechaInicio;
    private Date fechaCierre;
    private ArrayList<SprintsEntity> cantidadSprints;
    
    public ProyectoEntity(String nombreProyecto, Date fechaInicio, Date fechaCierre, String identificador){
        this.nombreProyecto = nombreProyecto;
        this.fechaInicio = fechaInicio;
        this.fechaCierre = fechaCierre;
        this.identificador = identificador;
    }

    /**
     * @return the identificador
     */
    public String getIdentificador() {
        return identificador;
    }

    /**
     * @param identificador the identificador to set
     */
    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    /**
     * @return the nombreProyecto
     */
    public String getNombreProyecto() {
        return nombreProyecto;
    }

    /**
     * @param nombreProyecto the nombreProyecto to set
     */
    public void setNombreProyecto(String nombreProyecto) {
        this.nombreProyecto = nombreProyecto;
    }

    public ArrayList<SprintsEntity> getCantidadSprints() {
        return cantidadSprints;
    }

    /**
     * @param cantidadSprints the cantidadSprints to set
     */
    public void setCantidadSprints(SprintsEntity Sprint) {
        this.cantidadSprints.add(Sprint);
    }

    /**
     * @return the fechaInicio
     */
    public Date getFechaInicio() {
        return fechaInicio;
    }

    /**
     * @param fechaInicio the fechaInicio to set
     */
    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    /**
     * @return the fechaCierre
     */
    public Date getFechaCierre() {
        return fechaCierre;
    }

    /**
     * @param fechaCierre the fechaCierre to set
     */
    public void setFechaCierre(Date fechaCierre) {
        this.fechaCierre = fechaCierre;
    }
    
}
