package com.una.administradordeproyectos.Colaborador;

import java.util.Collection;

/**
 * @author molin
 * @author hilde
 * @author antho
 */
public interface ColaboradorInterface {
    public String crear(String[]data);
    public String modificar(String[] data);
    public String[] find(String cedula);
    public String eliminar(String cedula);
    public String[] mostrarTodos();
    public String[]mostrarTareasDeUnColaborador(String cedula);
}
