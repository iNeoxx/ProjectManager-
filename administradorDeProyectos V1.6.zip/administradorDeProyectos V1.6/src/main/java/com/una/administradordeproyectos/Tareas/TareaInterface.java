package com.una.administradordeproyectos.Tareas;

import java.text.ParseException;
import java.util.Date;

/**
 * @author molin
 * @author hilde
 * @author antho
 */
public interface TareaInterface {
    public String crear(String[] data, int num, Date[] fechas);
    public String modificar(String []data);
    public String[] buscar(String identificador);
    public String eliminar(String identificador);
    public String agregarColaborador(String identificador, String cedula);
    public String eliminarColaborador(String identificador);
    public String[] mostrarTodos();
    public String generarIdentificador(String proyId, int num);
    public Date[] verificarCrearFechas(String[] data) throws ParseException;
}
