/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Tareas;

import com.una.administradordeproyectos.Colaborador.ColaboradorContainer;
import com.una.administradordeproyectos.Sprints.SprintsContainer;
import java.util.Collection;

/**
 *
 * @author antho
 */
public class TareaController implements TareaInterface{

    @Override
    public String crear(String[] data, int idTarea) {
       String respuesta = "Tarea ya creada previamente";
       String identificador = generarIdentificador(data[0], idTarea);
       if(!TareaContainer.existe(identificador)){
           TareaEntity nTarea = new TareaEntity(data, identificador);
           SprintsContainer.buscar(data[0]).setTarea(nTarea);
           nTarea.setSprints(SprintsContainer.buscar(data[0]));
           if(TareaContainer.agregar(nTarea)){
               respuesta = "Tarea agregada correctamente";
           }else{
               respuesta = "Error al agregar la tarea";
           }
       }
       return respuesta;
    }
    @Override
    public String generarIdentificador(String idSprint, int idTarea){
      String identificador;
        if(idTarea < 10){
            identificador = idSprint + "-" + 0 + idTarea;
        }else{
            identificador = idSprint + "-" + idTarea;
        }
        return identificador;
    }
    @Override
    public String modificar(String[] data) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    @Override
    /**
     * 
     * @param data 0 = identificador, 1 = descripcion, 2 = nombreColaborador, 3 = recursos
     */
    public String[] buscar(String identificador) {
       TareaEntity tarea;
       if(TareaContainer.existe(identificador)){
           tarea = TareaContainer.buscar(identificador);
           if(tarea.getColaborador()!=null){
               String[] data = {tarea.getIdentificador(),tarea.getDescripcion(), tarea.getColaborador().getNombre(), tarea.getRecursos()};//Solo devuelve el nombre del colaborador
               return data;
           }
            String[] data = {tarea.getIdentificador(),tarea.getDescripcion(), "NO ASIGNADO", " Recursos: "+tarea.getRecursos(), 
                " Fecha Inicio: " + tarea.getFechaInicio().getDate() + "/" + (tarea.getFechaInicio().getMonth() + 1) + "/" + (tarea.getFechaInicio().getYear() + 1900), " Fecha Cierre: " + tarea.getFechaCierre().getDate() + "/" + (tarea.getFechaCierre().getMonth() + 1) + "/" + (tarea.getFechaCierre().getYear() + 1900)};
           return data;
       }
        return null;
    }

    @Override
    public String eliminar(String identificador) {
         String respuesta = "No existe ninguna tarea con ese identificador";
       if(TareaContainer.existe(identificador)){
           if(TareaContainer.eliminar(identificador)){
               respuesta = "Tarea Eliminada correctamente";
           }else{
               respuesta = "Error al eliminar la tarea";
           }
       }
        return respuesta;
    }

    @Override
    public String agregarColaborador(String identificador, String cedula) {
      String respuesta = "Error al asignar el colaborador a tarea";
      if(TareaContainer.existe(identificador)){
          if(ColaboradorContainer.exist(cedula)){
              if(ColaboradorContainer.find(cedula).getEstado() == false){//Tiene que ser falso = INACTIVO
                   TareaContainer.agregarColaborador(identificador, ColaboradorContainer.find(cedula));
                   respuesta = "Se ha asignado el colaborador";
              }else{
                  respuesta = "ERROR, el colaborador ya está ACTIVO";
              }
          }
      }
        return respuesta;
    }

    @Override
    public String eliminarColaborador(String identificador) {
       String respuesta= "Error al eliminar el colaborador de tarea";
       if(TareaContainer.eliminarColaborador(identificador)){
           respuesta = "Se ha eliminado el colaborador";
           
       }
       return respuesta;
    }
    
    
    @Override
    public String[] mostrarTodos() {
        if(TareaContainer.mostrarTodos()!= null){
            Collection<TareaEntity> tareas = TareaContainer.mostrarTodos();
            String []data = new String[tareas.size()];
            int i = 0;
            for(Object c:tareas){
                 TareaEntity tarea = (TareaEntity)c;
                 if(tarea.getColaborador()!=null){ 
                    data[i] = "Identificador: "+tarea.getIdentificador()+" Descripcion: "+tarea.getDescripcion()+" Colaborador: "+tarea.getColaborador().getNombre()+" "+tarea.getColaborador().getApellidos()+" Recursos: "+tarea.getRecursos() +
                            " Fecha Inicio: " + tarea.getFechaInicio().getDate() + "/" + (tarea.getFechaInicio().getMonth() + 1) + "/" + (tarea.getFechaInicio().getYear() + 1900) + " Fecha Cierre: " + tarea.getFechaCierre().getDate() + "/" + (tarea.getFechaCierre().getMonth() + 1) + "/" + (tarea.getFechaCierre().getYear() + 1900);
                 }else{
                      data[i] = "Identificador: "+tarea.getIdentificador()+" Descripcion: "+tarea.getDescripcion()+" Colaborador: NO ASIGNADO"+" Recursos: "+tarea.getRecursos();
                 }
                 i++;
            }
            return data;
        }
        return null;
    }
    
    
}
