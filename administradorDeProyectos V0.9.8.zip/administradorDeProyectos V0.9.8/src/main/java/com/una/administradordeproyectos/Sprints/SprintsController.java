/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Sprints;

import com.una.administradordeproyectos.Proyecto.ProyectoContainer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

/**
 *
 * @author antho
 */
public class SprintsController implements SprintsInterface{
    
    @Override
    public String crear(String data [], int num) throws ParseException { //arbusto denegado (flash + q)
        String respuesta = "Sprint ya creado previamente";
        String idProyect = data[0];
        String sprintId = generarIdentificador(data[0], num);
        if(ProyectoContainer.existe(idProyect)){  
            if(!SprintsContainer.existe(sprintId)){
            Date fechaInicio = new SimpleDateFormat("dd/MM/yyyy").parse(data[1]);
            Date fechaFinal = new SimpleDateFormat("dd/MM/yyyy").parse(data[2]);
            SprintsEntity nSprint = new SprintsEntity(sprintId, fechaInicio, fechaFinal);
            ProyectoContainer.buscar(idProyect).setSprints(nSprint);
            nSprint.setProyecto(ProyectoContainer.buscar(idProyect));
           if(SprintsContainer.crear(nSprint)){
               respuesta = "Sprint agregado al proyecto " + idProyect + " correctamente";
           }
           else{
               respuesta = "Error al agregar el sprint";
           }
        }
        }
        else{
          respuesta = "Error al agregar el sprint, ese proyecto no existe";  
        }
       return respuesta;
    } 
    @Override
    public String[] buscar(String identificador) {
       if(SprintsContainer.existe(identificador)){
            SprintsEntity sprint = SprintsContainer.buscar(identificador);
            String[] data = {"Identificador: "+sprint.getIdentificador(),"Fecha Inicio: " + sprint.getFechaInicio().getDate()+ "/" + (sprint.getFechaInicio().getMonth()+1) + "/" + (sprint.getFechaInicio().getYear() + 1900), "Fecha Cierre: " + (sprint.getFechaCierre().getDate()+1) + "/" + (sprint.getFechaCierre().getMonth()+1) + "/" + (sprint.getFechaCierre().getYear() + 1900)};
            return data;
        }
       return null;
    }
    
    @Override
    public String modificar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public String[] mostrarTodos() {
       if(SprintsContainer.mostrarTodos() != null){
           Collection<SprintsEntity> sprints = SprintsContainer.mostrarTodos();
           String []data = new String[sprints.size()];
           int i = 0;
           for(Object c:sprints){
               SprintsEntity sprint = (SprintsEntity)c;
               data[i] = "Identificador: "+sprint.getIdentificador() + " Fecha Inicio: " + sprint.getFechaInicio().getDate() + "/" + (sprint.getFechaInicio().getMonth()+1) + "/" + (sprint.getFechaInicio().getYear() + 1900) +
                       " Fecha Cierre: " + sprint.getFechaCierre().getDate() + "/" + (sprint.getFechaCierre().getMonth()+1) + "/" + (sprint.getFechaCierre().getYear() + 1900);
               i++;
           }
           return data;
       }
       return null;
    }
    @Override
    public String generarIdentificador(String proyId, int num){
      String identificador;
        if(num < 10){
            identificador = proyId + "-" + 0 + num;
        }else{
            identificador = proyId + "-" + num;
        }
        return identificador;
    }
}
