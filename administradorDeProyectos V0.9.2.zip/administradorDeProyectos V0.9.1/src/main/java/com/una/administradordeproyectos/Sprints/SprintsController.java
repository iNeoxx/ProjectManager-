/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Sprints;

import com.una.administradordeproyectos.Proyecto.ProyectoContainer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author antho
 */
public class SprintsController implements SprintsInterface{
    
    @Override
    public String crear(String data []) throws ParseException { //arbusto denegado (flash + q)
        String respuesta = "Sprint ya creado previamente";
        
       if(!SprintsContainer.existe(data[0])){
            Date fechaInicio = new SimpleDateFormat("dd/MM/yyyy").parse(data[1]);
            Date fechaFinal = new SimpleDateFormat("dd/MM/yyyy").parse(data[2]);
            SprintsEntity nSprint = new SprintsEntity(data[0], fechaInicio, fechaFinal);
            //ProyectoContainer.buscar(data[0]).getCantidadSprints().crear(nSprint);
           if(SprintsContainer.crear(nSprint)){
               respuesta = "Sprint agregado correctamente";
           }else{
               respuesta = "Error al agregar el sprint";
           }
       }
       return respuesta;
       
    } 
    
    @Override
    public String[] buscar(String identificador) {
       if(ProyectoContainer.existe(identificador)){
            SprintsEntity sprint = SprintsContainer.buscar(identificador);
            String[] data = {"Identificador: "+sprint.getIdentificador(),"Fecha Inicio: " + sprint.getFechaInicio(), "Fecha Cierre: " + sprint.getFechaCierre()};
            return data;
        }
       return null;
    }
    
    @Override
    public String modificar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public String[] mostrar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
