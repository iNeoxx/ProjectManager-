/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos;
//se importan los paquetes si no no funca
import com.una.administradordeproyectos.Colaborador.ColaboradorController;
import com.una.administradordeproyectos.Colaborador.ColaboradorInterface;
import com.una.administradordeproyectos.Tareas.TareaController;
import com.una.administradordeproyectos.Tareas.TareaInterface;

/**
 *
 * @author antho
 */
public class MainController {
    public static void main(String[] args) {
        int opcion;
        String respuesta;
        String menuOptions[] = {"Modulo Colaborador","Modulo Tarea","Modulo","Modulo","Modulo","Salir"};
        do{
            opcion = UI.menu("Menu Modulos",menuOptions);//Se crea el menu y se retorna la opcion que dijito el usuario
            switch(opcion){
                case 0://Modulo Colaborador
                    moduloColaborador();
                    break;
                case 1://Modulo Tarea
                    moduloTarea();
                    break;
                case 2://Modulo
                    break;
                case 3://Modulo
                    break;
                case 4://Modulo
                    break;
                case 5://Salir
                    UI.outLine("Saliendo del sistema");
                    break;
                default:
                    UI.outLine("Digite una opcion valida");
                    break;
            }
        }while(opcion != 5);
    }
    //Modulos
    private static void moduloColaborador(){
        ColaboradorInterface colaborador = new ColaboradorController();//instancia de controlador
        int opcion;
        String identificador;
        String respuesta;
        String menuOptions[] = {"Crear","buscar","Modificar","Eliminar","Mostrar todos","Menu principal"};
        do{
            opcion = UI.menu("SubMenu Colaborador",menuOptions);//muestra el menu y retorna la opcion del usuario
            switch(opcion){
                case 0://Crear
                    String data[] = {"Cedula","Nombre","Apellidos","Telefono","Email","Especialidad", "Estado"};
                    data = UI.input("Datos del Colaborador", data);
                    respuesta = colaborador.crear(data);//Create de controlador
                    UI.outLine(respuesta);//respuesta
                    break;
                case 1://Buscar
                    identificador = UI.input("Ingrese la cedula del colaborador");
                    String[] colaboradorData = colaborador.find(identificador);//se manda el identificador y retorna los datos del colaborador
                   if(colaboradorData != null){
                       UI.outLine("------Datos del Colaborador almacenado------");
                       for(String line:colaboradorData){
                           UI.outLine(line);
                       }
                   }else{
                       UI.outLine("No existe ningun colaborador con esa cedula");
                   }
                    break;
                case 2://Modificar "revisar, esta manera es poco practico"
                    String data1[] = {"Cedula del colaborador a reemplazar","Nombre","Apellidos","Telefono","Email","Especialidad", "Estado"};
                    data1 = UI.input("Datos del nuevo colaborador", data1);
                    respuesta = colaborador.modificar(data1);
                    UI.outLine(respuesta);
                    break;
                case 3://Eliminar
                    identificador = UI.input("Ingrese la cedula del colaborador a eliminar");
                    respuesta = colaborador.eliminar(identificador);
                    UI.outLine(respuesta);
                    break;
                case 4://Mostrar Todos
                    String colaboradorLista[] = colaborador.mostrarTodos();
                    if(colaboradorLista != null){
                        UI.outLine("============Lista de Colaboradores============");
                        for(String line:colaboradorLista){
                            UI.outLine(line);
                        }
                        UI.outLine("==============================================");
                    }else{
                        UI.outLine("No existen colaboradores en el contenedor");
                    }
                    break;
                case 5:
                    UI.outLine("Volviendo al Menu Principal");
                    break;
                default:
                    UI.outLine("Digite una opcion valida");
                    break;
            }
        }while(opcion != 5);
        
    }
    private static void moduloTarea(){
        TareaInterface tarea = new TareaController();
        int optUser;
        String identificador;
        String respuesta;
        String menuOptions[] = {"Crear","buscar","Eliminar","Asignar Colaborador","Eliminar Colaborador","Mostrar todos","Menu principal"};
        do{
            optUser = UI.menu("Modulo Tarea",menuOptions);
            switch(optUser){
                case 0://Crear
                    String data[] = {"Identificador","Descripcion","Recursos"};
                    data = UI.input("Datos de la Tarea", data);
                    respuesta = tarea.crear(data);
                    UI.outLine(respuesta);
                    break;
                case 1://buscar
                     identificador = UI.input("Ingrese el identificador de tarea a consultar");
                    String tareaData[]=tarea.buscar(identificador);
                    if(tareaData!=null){
                        UI.outLine("=======Datos de la tarea alamacenada========");
                        for(String line:tareaData){
                            UI.outLine(line);
                        }
                    }else{
                        UI.outLine("No existe ninguna tarea con ese identificador");
                    }
                    break;
                case 2://Eliminar
                    identificador = UI.input("Ingrese el identificador de la tarea a eliminar");
                    respuesta = tarea.eliminar(identificador);
                    UI.outLine(respuesta);
                    break;
                case 3://Asignar Colaborador
                    identificador = UI.input("Ingrese el identificador de tarea");
                    String cedula = UI.input("Ingrese la cedula del colaborador");
                    respuesta = tarea.agregarColaborador(identificador, cedula);
                    UI.outLine(respuesta);
                    break;
                case 4://Eliminar Colaborador
                    identificador = UI.input("Ingrese el identificador de tarea");
                    respuesta = tarea.eliminarColaborador(identificador);
                    UI.outLine(respuesta);
                    break;
                case 5://Mostrat todos
                    String tareaLista[] = tarea.mostrarTodos();
                    if(tareaLista != null){
                        UI.outLine("============Lista de Tareas============");
                        for(String line:tareaLista){
                            UI.outLine(line);
                        }
                        UI.outLine("==============================================");
                    }else{
                        UI.outLine("No existen Tareas en el contenedor");
                    }
                    break;
                case 6:
                    UI.outLine("Volviendo al menu principal");
                    break;
                default:
                    UI.outLine("Opcion no valida");
                    break;
            }
        }while(optUser != 6);
    }
}
