/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Tareas;

/**
 *
 * @author antho
 */
public interface TareaInterface {
    public String crear(String []data);
    public String modificar(String []data);
    public String[] buscar(String identificador);
    public String eliminar(String identificador);
    public String agregarColaborador(String identificador, String cedula);
    public String eliminarColaborador(String identificador);
    public String[] mostrarTodos();
}
