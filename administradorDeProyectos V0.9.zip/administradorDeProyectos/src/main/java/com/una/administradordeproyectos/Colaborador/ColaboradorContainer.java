/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Colaborador;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author antho
 */
public class ColaboradorContainer {
    //HashMap almacen
     private static Map<String,ColaboradorEntity> cColaborador = new HashMap<String,ColaboradorEntity>();
     //KEY es identificador de colaborador
     //CRUD
     public static boolean add(ColaboradorEntity colaborador){
         if(!cColaborador.containsKey(colaborador.getCedula())){
             cColaborador.put(colaborador.getCedula(), colaborador);
             return true;
         }
         return false;
     }
     //verifica existencia
     public static boolean exist(String cedula){
         if(cColaborador.containsKey(cedula)){
             return true;
         }
         return false;
     }
     //busca y retorna colaborador
    public static ColaboradorEntity find(String identificador){
         ColaboradorEntity colaborador;
         if(cColaborador.containsKey(identificador)){ 
             colaborador = cColaborador.get(identificador);
             return colaborador;
         }
         return null;
     }
     
    public static boolean update(ColaboradorEntity newColaborador, String cedula){//se recibe el nuevo colaborador y cedula
          if(cColaborador.containsKey(cedula)){//se verifica la existencia
            ColaboradorEntity oldColaborador = cColaborador.get(cedula);//se extrae el colaborador a reemplazar
            cColaborador.replace(cedula, oldColaborador, newColaborador);//se reemplaza
            return true;
          }
        return false;
    }
      
    public static boolean delete(String cedula){//recibe la cedula
        if(cColaborador.containsKey(cedula)){//verifica existencia
            cColaborador.remove(cedula);
            return true;
        }
        return false;
    }
    
    public static Collection<ColaboradorEntity> getAll(){
         Collection<ColaboradorEntity> colaboradores = cColaborador.values();
        if(!cColaborador.isEmpty()){
            return colaboradores;
        }
        return null;
    }
}
