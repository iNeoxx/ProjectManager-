/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Proyecto;

import com.una.administradordeproyectos.Sprints.SprintsEntity;
import java.util.ArrayList;

/**
 *
 * @author antho
 */
public class ProyectoEntity {
    private String identificador;
    private String nombreProyecto;
    private String fechaInicio;
    private String fechaCierre;
    private ArrayList<SprintsEntity> cantidadSprints;
    
    public ProyectoEntity(String[] data){
        this.nombreProyecto=data[0];
    }

    /**
     * @return the identificador
     */
    public String getIdentificador() {
        return identificador;
    }

    /**
     * @param identificador the identificador to set
     */
    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    /**
     * @return the nombreProyecto
     */
    public String getNombreProyecto() {
        return nombreProyecto;
    }

    /**
     * @param nombreProyecto the nombreProyecto to set
     */
    public void setNombreProyecto(String nombreProyecto) {
        this.nombreProyecto = nombreProyecto;
    }

    /**
     * @return the fechaInicio
     */
    public String getFechaInicio() {
        return fechaInicio;
    }

    /**
     * @param fechaInicio the fechaInicio to set
     */
    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    /**
     * @return the fechaCierre
     */
    public String getFechaCierre() {
        return fechaCierre;
    }

    /**
     * @param fechaCierre the fechaCierre to set
     */
    public void setFechaCierre(String fechaCierre) {
        this.fechaCierre = fechaCierre;
    }

    /**
     * @return the cantidadSprints
     */
    public ArrayList<SprintsEntity> getCantidadSprints() {
        return cantidadSprints;
    }

    /**
     * @param cantidadSprints the cantidadSprints to set
     */
    public void setCantidadSprints(ArrayList<SprintsEntity> cantidadSprints) {
        this.cantidadSprints = cantidadSprints;
    }
    
}
