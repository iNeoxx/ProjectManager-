/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Sprints;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author antho
 */
public class SprintsContainer {
    private static Map<String,SprintsEntity> eSprints = new HashMap<String,SprintsEntity>();
     //KEY es identificador de Sprints
}
