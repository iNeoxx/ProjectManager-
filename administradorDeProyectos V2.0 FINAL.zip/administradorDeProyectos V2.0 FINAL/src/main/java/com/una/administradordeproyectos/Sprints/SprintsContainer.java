package com.una.administradordeproyectos.Sprints;

import com.una.administradordeproyectos.Proyecto.ProyectoEntity;
import com.una.administradordeproyectos.Tareas.TareaContainer;
import com.una.administradordeproyectos.Tareas.TareaEntity;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @author molin
 * @author hilde
 * @author antho
 */
public class SprintsContainer {

    private static Map<String, SprintsEntity> cSprints = new HashMap<String, SprintsEntity>();
    //KEY es identificador de Sprints

    public static boolean agregar(SprintsEntity sprint) {
        if (!cSprints.containsKey(sprint.getIdentificador())) {
            cSprints.put(sprint.getIdentificador(), sprint);
            return true;
        }
        return false;
    }

    public static boolean existe(String identificador) {
        if (cSprints.containsKey(identificador)) {
            return true;
        }
        return false;
    }

    public static SprintsEntity buscar(String identificador) {
        SprintsEntity sprint;
        if (cSprints.containsKey(identificador)) {
            sprint = cSprints.get(identificador);
            return sprint;
        }
        return null;
    }

    public static boolean eliminar(String identificador) {
        if (cSprints.containsKey(identificador)) {
            ArrayList tareas = cSprints.get(identificador).getTareas();
            for(Object c:tareas){
                TareaEntity tarea = (TareaEntity) c;
                TareaContainer.eliminar(tarea);
            }
            cSprints.remove(identificador);
            return true;
        }
        return false;
    }
    
    public static Collection<SprintsEntity> mostrarTodos() {
        Collection<SprintsEntity> sprints = cSprints.values();
        if (!cSprints.isEmpty()) {
            return sprints;//desengage nauti (flash + Q) adc rival denegado 
        }
        return null;
    }
}
