package com.una.administradordeproyectos.Colaborador;

import com.una.administradordeproyectos.Persona;
import com.una.administradordeproyectos.Tareas.TareaEntity;
import java.util.ArrayList;

/**
 * @author molin
 * @author hilde
 * @author antho
 */
public class ColaboradorEntity extends Persona{
    //Atributo
    private String especialidad;
    private boolean estado;
    private ArrayList<TareaEntity> tareas;
    
     /**
     * @param data
    @param  0=cedula,1=nombre,2=apellidos,3=telefono,4=email,5=especialidad,6=estado
    */
    public ColaboradorEntity(String [] data){
        this.setCedula(data[0]);
        this.setNombre(data[1]);
        this.setApellidos(data[2]);
        this.setTelefono(data[3]);
        this.setEmail(data[4]);
        this.especialidad = data[5];
        this.estado = true;
        this.tareas = new ArrayList<>();
    }

    /**
     * @return the especialidad
     */
    public String getEspecialidad() {
        return especialidad;
    }

    /**
     * @param especialidad the especialidad to set
     */
    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    /**
     * @return the estado
     */
    public boolean getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    /**
     * @return the tareas
     */
    public ArrayList<TareaEntity> getTareas() {
        return tareas;
    }

    /**
     * @param tarea the tareas to set
     */
    public void setTareas(TareaEntity tarea) {
        this.tareas.add(tarea);
    }
}
