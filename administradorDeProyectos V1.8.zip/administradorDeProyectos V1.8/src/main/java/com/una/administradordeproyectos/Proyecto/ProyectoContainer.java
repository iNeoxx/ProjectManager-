package com.una.administradordeproyectos.Proyecto;

import com.una.administradordeproyectos.Sprints.SprintsContainer;
import com.una.administradordeproyectos.Sprints.SprintsEntity;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.HashMap;
import java.util.List;

/**
 * @author molin
 * @author hilde
 * @author antho
 */
public class ProyectoContainer {

    //Key = identificador del proyecto
    private static Map<String, ProyectoEntity> cProyecto = new HashMap<String, ProyectoEntity>();

    public static boolean agregar(ProyectoEntity proyecto) {
        if (!cProyecto.containsKey(proyecto.getIdentificador())) {
            cProyecto.put(proyecto.getIdentificador(), proyecto);
            return true;
        }
        return false;
    }

    public static boolean existe(String identificador) {
        if (cProyecto.containsKey(identificador)) {
            return true;
        }
        return false;
    }

    public static ProyectoEntity buscar(String identificador) {
        if (cProyecto.containsKey(identificador)) {
            ProyectoEntity proyecto = cProyecto.get(identificador);
            return proyecto;
        }
        return null;
    }

    public static boolean eliminar(String identificador) {
        if (cProyecto.containsKey(identificador)) {
            cProyecto.remove(identificador);
            return true;
        }
        return false;
    }

    public static void eliminarAux(String identificador){
        ArrayList sprints = cProyecto.get(identificador).getSprints();
        for (Object c : sprints) {//recorre el arraylist
            SprintsEntity sprint = (SprintsEntity) c;
            if (sprint != null) {
                String identificadorS = sprint.getIdentificador();
                SprintsContainer.eliminar(identificadorS);//se manda a llaamr el eliminar de cada sprint para repetir el proceso   
            }
        }
        cProyecto.remove(identificador);
    }

    public static Collection<ProyectoEntity> mostrarTodos() {
        if (!cProyecto.isEmpty()) {
            Collection<ProyectoEntity> proyecto = cProyecto.values();
            return proyecto;
        }
        return null;
    }

}
