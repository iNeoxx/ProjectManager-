package com.una.administradordeproyectos;
//se importan los paquetes si no no funca

import com.una.administradordeproyectos.Colaborador.ColaboradorContainer;
import com.una.administradordeproyectos.Colaborador.ColaboradorController;
import com.una.administradordeproyectos.Colaborador.ColaboradorInterface;
import com.una.administradordeproyectos.Proyecto.ProyectoContainer;
import com.una.administradordeproyectos.Proyecto.ProyectoController;
import com.una.administradordeproyectos.Proyecto.ProyectoInterface;
import com.una.administradordeproyectos.Sprints.SprintsContainer;
import com.una.administradordeproyectos.Sprints.SprintsController;
import com.una.administradordeproyectos.Sprints.SprintsInterface;
import com.una.administradordeproyectos.Tareas.TareaContainer;
import com.una.administradordeproyectos.Tareas.TareaController;
import com.una.administradordeproyectos.Tareas.TareaInterface;
import java.text.ParseException;
import java.util.Date;

/**
 * @author molin
 * @author hilde
 * @author antho
 */
public class MainController {

    static int idProyecto = 1;//numero de id (ira aumentado)
    static int idSprints = 1;
    static int idTarea = 1;
    static String letraP = "P";//letra de proyecto P
    //main

    public static void main(String[] args) throws ParseException {
        int opcion;
        String respuesta;
        String menuOptions[] = {"Modulo Proyecto", "Modulo Sprint", "Modulo Tarea", "Modulo Colaborador", "Salir"};
        do {
            opcion = UI.menu("MENU MODULOS", menuOptions);//Se crea el menu y se retorna la opcion que dijito el usuario
            switch (opcion) {
                case 0://Modulo Proyecto
                    moduloProyecto();
                    break;
                case 1://Modulo Sprint
                    moduloSprints();
                    break;
                case 2://Modulo Tarea
                    moduloTarea();
                    break;
                case 3://Modulo Colaborador
                    moduloColaborador();
                    break;
                case 4://salir
                    UI.outLine("Saliendo del programa :)");
                    UI.outLine("Programa creado por Anthony Eras, Domingo Molina y Hilder Ordoñez");
                    break;
                default:
                    UI.outLine("La opcion que usted quiere ingresar es incorrecta, por favor digite una opcion valida");
                    break;
            }
        } while (opcion != 4);
    }

    //Modulos
    public static void moduloColaborador() {
        ColaboradorInterface colaborador = new ColaboradorController();//instancia de controlador
        int opcion;
        String cedulaC;
        String respuesta;
        String menuOptions[] = {"Crear", "buscar", "Modificar", "Eliminar", "Mostrar todos", "Mostrar Tareas de un Colaborador", "Menu principal"};
        do {
            opcion = UI.menu("MODULO COLABORADORES", menuOptions);//muestra el menu y retorna la opcion del usuario
            switch (opcion) {
                case 0://Crear
                    String data[] = {"Ingrese la cedula: ", "Ingrese el nombre", "Ingrese los apellidos: ", "Ingrese el telefono: ", "Ingrese el email: ", "Ingrese la especialidad: "};
                    data = UI.input("Datos del Colaborador", data);
                    respuesta = colaborador.crear(data);//Create de controlador
                    UI.outLine(respuesta);//respuesta
                    break;
                case 1://Buscar
                    cedulaC = UI.input("Ingrese la cedula del colaborador");
                    String[] colaboradorData = colaborador.find(cedulaC);//se manda el identificador y retorna los datos del sprint
                    if (colaboradorData != null) {
                        UI.outLine("------Datos del Colaborador almacenado------");
                        for (String line : colaboradorData) {
                            UI.outLine(line);
                        }
                    } else {
                        UI.outLine("No existe ningun colaborador con esa cedula");
                    }
                    break;
                case 2://Modificar
                    String cedula = UI.input("Ingrese la cedula del colaborador a modificar");
                    if (ColaboradorContainer.exist(cedula)) {
                        String menuModificar[] = {"Modificar Nombre ","Modificar Apellidos ","Modificar Telefono ","Modificar Email ","Modificar Especialidad ","Modificar Estado"};
                        int opcionM = UI.menu("MODULO MODIFICAR COLABORADOR", menuModificar);
                        switch (opcionM) {
                            case 0: //1=nombre,2=apellidos,3=telefono,4=email,5=especialidad,6=estado
                                String nombre = UI.input("Ingrese el nombre nuevo: ");
                                String dataM[] = {cedula, nombre};
                                respuesta = colaborador.modificar(dataM, opcionM);
                                UI.outLine(respuesta);
                                break;
                            case 1:
                                String apellido = UI.input("Ingrese el apellido nuevo: ");
                                String dataM2[] = {cedula, apellido};
                                respuesta = colaborador.modificar(dataM2, opcionM);
                                UI.outLine(respuesta);
                                break;
                            case 2:
                                String telefono = UI.input("Ingrese el telefono nuevo: ");
                                String dataM3[] = {cedula, telefono};
                                respuesta = colaborador.modificar(dataM3, opcionM);
                                UI.outLine(respuesta);
                                break;
                            case 3:
                                String email = UI.input("Ingrese el email nuevo: ");
                                String dataM4[] = {cedula, email};
                                respuesta = colaborador.modificar(dataM4, opcionM);
                                UI.outLine(respuesta);
                                break;
                            case 4:
                                String especialidad = UI.input("Ingrese la especialidad nuevo: ");
                                String dataM5[] = {cedula, especialidad};
                                respuesta = colaborador.modificar(dataM5, opcionM);
                                UI.outLine(respuesta);
                                break;
                            case 5:
                                String dataM6[] = {cedula, null};
                                respuesta = colaborador.modificar(dataM6, opcionM);
                                UI.outLine(respuesta);
                                break;
                            case 6:
                                UI.outLine("Volviendo al menu de Colaborador");
                                break;
                        }
                    } else {
                        UI.outLine("No existe ningun Colaborador con esa cedula");
                    }
                    break;
                case 3://Eliminar
                    cedulaC = UI.input("Ingrese la cedula del colaborador a eliminar");
                    respuesta = colaborador.eliminar(cedulaC);
                    UI.outLine(respuesta);
                    break;
                case 4://Mostrar Todos
                    String colaboradorLista[] = colaborador.mostrarTodos();
                    if (colaboradorLista != null) {
                        UI.outLine("============Lista de Colaboradores============");
                        for (String line : colaboradorLista) {
                            UI.outLine(line);
                        }
                        UI.outLine("==============================================");
                    } else {
                        UI.outLine("No existen colaboradores en el contenedor");
                    }
                    break;
                case 5://Mostrar tareas de un colaborador
                    cedulaC = UI.input("Digite la cedula del colaborador:");
                    String[] tareaList = colaborador.mostrarTareasDeUnColaborador(cedulaC);
                    if (tareaList != null) {
                        UI.outLine("==============================================");
                        UI.outLine("Tareas del Colaborador: " + cedulaC + ": ");
                        for (String line : tareaList) {
                            UI.outLine(line);
                        }
                    } else {
                        UI.outLine("No existen Tareas aginadas a ese Colaborador o el identificador no es valido");
                    }
                    break;
                case 6:
                    UI.outLine("Volviendo al Menu Principal");
                    break;
                default:
                    UI.outLine("La opcion que usted quiere ingresar es incorrecta, por favor digite una opcion valida");
                    break;
            }
        } while (opcion != 6);

    }

    public static void moduloTarea() throws ParseException {
        TareaInterface tarea = new TareaController();
        int opcion;
        String identificador;
        String respuesta;
        String menuOptions[] = {"Crear", "buscar", "Modificar", "Eliminar", "Asignar Colaborador", "Eliminar Colaborador de una tarea", "Mostrar todos", "Menu principal"};
        do {
            opcion = UI.menu("MODULO TAREA", menuOptions);
            switch (opcion) {
                case 0://Crear
                    String data[] = {"Identificador de Sprint", "Descripcion", "Recursos", "Ingrese las fechas de la Tarea con el siguiente formato dd/MM/yyyy, ejemplo: 01/01/2021. Recuerde que estas fechas deben coincidir con las del Sprint correspondiente\nIngrese la fecha Inicio:", "Ingrese la fecha Cierre:"};
                    data = UI.input("Datos de la Tarea", data);
                    if (SprintsContainer.existe(data[0])) {
                        Date[] fechas = tarea.verificarCrearFechas(data);
                        if (fechas != null) {
                            respuesta = tarea.crear(data, idTarea, fechas);//Create de controlador
                            UI.outLine(respuesta);//respuesta
                            idTarea++;
                            break;
                        } else {
                            UI.outLine("Las fechas que ha ingresado no coinciden con las de Sprint");
                            break;
                        }
                    } else {
                        UI.outLine("No existe ningun Sprint con ese identificador");
                    }
                    break;
                case 1://buscar
                    identificador = UI.input("Ingrese el identificador de tarea a consultar");
                    String tareaData[] = tarea.buscar(identificador);
                    if (tareaData != null) {
                        UI.outLine("=======Datos de la tarea alamacenada========");
                        for (String line : tareaData) {
                            UI.outLine(line);
                        }
                    } else {
                        UI.outLine("No existe ninguna tarea con ese identificador");
                    }
                    break;
                case 2://Modificar
                    identificador = UI.input("Ingrese el identificador de la Tarea a modificar");
                    if (TareaContainer.existe(identificador)) {
                        String menuModificar[] = {"Modificar Descripcion", "Modificar Recursos", "salir"};
                        int opcionM = UI.menu("MODULO MODIFICAR TAREA", menuModificar);
                        switch (opcionM) {
                            case 0:
                                String descripcion = UI.input("Ingrese la descripcion nueva: ");
                                String dataM[] = {identificador, descripcion};
                                respuesta = tarea.modificar(dataM, opcionM);
                                UI.outLine(respuesta);
                                break;
                            case 1:
                                String recursoN = UI.input("Ingrese el/los recursos nuevos: ");
                                String dataM2[] = {identificador, recursoN};
                                respuesta = tarea.modificar(dataM2, opcionM);
                                UI.outLine(respuesta);
                                break;
                            case 3:
                                UI.outLine("Volviendo al menu Tarea");
                                break;
                        }
                    } else {
                        UI.outLine("No existe ninguna tarea con ese identificador");
                    }
                    break;
                case 3://Eliminar
                    identificador = UI.input("Ingrese el identificador de la tarea a eliminar");
                    respuesta = tarea.eliminar(identificador);
                    UI.outLine(respuesta);
                    break;
                case 4://Asignar Colaborador
                    identificador = UI.input("Ingrese el identificador de tarea");
                    String cedula = UI.input("Ingrese la cedula del colaborador");
                    respuesta = tarea.agregarColaborador(identificador, cedula);
                    UI.outLine(respuesta);
                    break;
                case 5://Eliminar Colaborador de una tarea y a su ves tambien se elimina tarea de colaborador
                    identificador = UI.input("Ingrese el identificador de tarea");
                    respuesta = tarea.eliminarColaborador(identificador);
                    UI.outLine(respuesta);
                    break;
                case 6://Mostrat todos
                    String tareaLista[] = tarea.mostrarTodos();
                    if (tareaLista != null) {
                        UI.outLine("============Lista de Tareas============");
                        for (String line : tareaLista) {
                            UI.outLine(line);
                        }
                        UI.outLine("==============================================");
                    } else {
                        UI.outLine("No existen Tareas en el contenedor");
                    }
                    break;
                case 7:
                    UI.outLine("Volviendo al menu principal");
                    break;
                default:
                    UI.outLine("La opcion que usted quiere ingresar es incorrecta, por favor digite una opcion valida");
                    break;
            }
        } while (opcion != 7);
    }

    public static void moduloProyecto() throws ParseException {
        ProyectoInterface proyecto = new ProyectoController();
        int opcion;
        String identificador;
        String respuesta;
        String menuOptions[] = {"Crear", "buscar", "modificar", "Eliminar", "Mostrar todos", "Mostrar Sprints de un proyecto", "Menu principal"};
        do {
            opcion = UI.menu("MODULO PROYECTO", menuOptions);
            switch (opcion) {
                case 0://crear 
                    String data[] = {"Nombre del proyecto", "Ingrese las fechas del proyecto con el siguiente formato dd/MM/yyyy, ejemplo: 01/01/2021\nIngrese la fecha de Inicio:", "Ingrese la fecha Final:"};
                    data = UI.input("Datos del proyecto", data);
                    respuesta = proyecto.crear(data, proyecto.generarIdentificador(letraP, idProyecto));
                    idProyecto += 1;
                    UI.outLine(respuesta);
                    break;
                case 1://buscar
                    identificador = UI.input("Ingrese el identificador del proyecto a consultar");
                    String proyectoData[] = proyecto.buscar(identificador);
                    if (proyectoData != null) {
                        UI.outLine("=======Datos del proyecto========");
                        for (String line : proyectoData) {
                            UI.outLine(line);

                        }
                    } else {
                        UI.outLine("No existe ningun proyecto con ese identificador");
                    }
                    break;
                case 2://Modificar
                    String[] data1 = {"Ingrese el identificador del proyecto a modificar: ", "Ingrese el nuevo nombre: "};
                    data1 = UI.input("Modificar proyecto", data1);
                    respuesta = proyecto.modificar(data1);
                    UI.outLine(respuesta);
                    break;
                case 3://eliminar
                    identificador = UI.input("Ingrese el identificador del proyecto a eliminar");
                    respuesta = proyecto.eliminar(identificador);
                    UI.outLine(respuesta);
                    break;
                case 4://mostrar todos
                    String[] proyectoLista = proyecto.mostrarTodos();
                    if (proyectoLista != null) {
                        UI.outLine("============Lista de proyectos============");
                        for (String line : proyectoLista) {
                            UI.outLine(line);
                        }
                        UI.outLine("==============================================");
                    } else {
                        UI.outLine("No existen proyectos en el contenedor");
                    }
                    break;

                case 5: //mostrar sprints de un proyecto
                    identificador = UI.input("Digite el identificador del proyecto:");
                    String[] sprintLista = proyecto.mostrarSprintsDeUnProyecto(identificador);
                    if (sprintLista != null) {
                        UI.outLine("==============================================");
                        UI.outLine("Sprints del proyecto " + identificador + ": ");
                        for (String line : sprintLista) {
                            UI.outLine(line);
                        }
                    } else {
                        UI.outLine("No existen Sprints en ese proyecto o el identificador no es valido");
                    }
                    break;
                case 6: //salir
                    UI.outLine("Volviendo al menu principal");
                    break;
                default:
                    UI.outLine("La opcion que usted quiere ingresar es incorrecta, por favor digite una opcion valida");
                    break;
            }
        } while (opcion != 6);
    }

    public static void moduloSprints() throws ParseException {
        SprintsInterface sprint = new SprintsController();//instancia de controlador
        int opcion;
        String respuesta;
        String menuOptions[] = {"Crear", "buscar", "Eliminar", "Mostrar todos", "Mostrar Tareas de un Sprint", "Menu principal"};
        String identificador;
        do {
            opcion = UI.menu("MODULO SPRINTS", menuOptions);//muestra el menu y retorna la opcion del usuario
            switch (opcion) {
                case 0://Crear
                    String data[] = {"Identificador del proyecto", "Ingrese las fechas del Sprint con el siguiente formato dd/MM/yyyy, ejemplo: 01/01/2021. Recuerde que estas fechas deben coincidir con los del proyecto correspondiente\nIngrese la fecha de Inicio:", "Ingrese la fecha Final:"};
                    data = UI.input("Datos del Sprint", data);
                    if (ProyectoContainer.existe(data[0])) {
                        Date[] fechas = sprint.verificarCrearFechas(data);
                        if (fechas != null) {
                            respuesta = sprint.crear(data[0], idSprints, fechas);//Create de controlador
                            UI.outLine(respuesta);//respuesta
                            idSprints++;
                            break;
                        } else {
                            UI.outLine("Las fechas que ha ingresado no coinciden con las de proyecto");
                            break;
                        }
                    } else {
                        UI.outLine("No existe ningun proyecto con ese Identificador");
                    }
                    break;
                case 1://Buscar
                    identificador = UI.input("Ingrese el identificador de Sprint");
                    String[] sprintData = sprint.buscar(identificador);//se manda el identificador y retorna los datos del sprint
                    if (sprintData != null) {
                        UI.outLine("------Datos del Sprint almacenado------");
                        for (String line : sprintData) {
                            UI.outLine(line);
                        }
                    } else {
                        UI.outLine("No existe ningun Sprint con ese identificador");
                    }
                    break;
                case 2://Eliminar
                    identificador = UI.input("Ingrese el identificador del Sprint a eliminar");
                    respuesta = sprint.eliminar(identificador);
                    UI.outLine(respuesta);
                    break;
                case 3://Mostrar Todos
                    String colaboradorLista[] = sprint.mostrarTodos();
                    if (colaboradorLista != null) {
                        UI.outLine("============Lista de Sprints============");
                        for (String line : colaboradorLista) {
                            UI.outLine(line);
                        }
                        UI.outLine("==============================================");
                    } else {
                        UI.outLine("No existen Sprints en el contenedor");
                    }
                    break;
                case 4://Mostrar tareas de un sprint
                    identificador = UI.input("Digite el identificador del sprint:");
                    String[] tareaList = sprint.mostrarTareasDeUnSprint(identificador);
                    if (tareaList != null) {
                        UI.outLine("Tareas del sprint" + identificador + ": ");
                        for (String line : tareaList) {
                            UI.outLine(line);
                        }
                        UI.outLine("==============================================");
                    } else {
                        UI.outLine("No existen Tareas asiginadas a ese Sprint o el identificador no es valido");
                    }
                    break;
                case 5:
                    UI.outLine("Volviendo al Menu Principal");
                    break;
                default:
                    UI.outLine("La opcion que usted quiere ingresar es incorrecta, por favor digite una opcion valida");
                    break;
            }
        } while (opcion != 5);

    }
}
