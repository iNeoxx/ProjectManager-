/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Tareas;

import com.una.administradordeproyectos.Colaborador.ColaboradorEntity;
import com.una.administradordeproyectos.Sprints.SprintsEntity;
import java.util.Date;

/**
 *
 * @author antho
 */
public class TareaEntity {
    private String identificador;
    private String descripcion;
    private ColaboradorEntity colaborador;
    private SprintsEntity sprints;//Sprints todavia no implementado
    private Date fechaInicio;//fecha todavia no implementado
    private Date fechaCierre;//fecha todavia no implementado
    private String recursos;
    
    /**
     * 
     * @param data 1 = descripcion, 2 = recursos
     * @param id
     * @param fechas 0 = fechaInicial, 1 = fechaFinal
     */
    public TareaEntity(String [] data, String id, Date[] fechas){//falta fechas y el sprint que todavia no esta creado
        this.identificador = id;
        this.descripcion = data[1];
        this.recursos = data[2];
        this.fechaInicio = fechas[0];
        this.fechaCierre = fechas[1];
    }
    
    /**
     * @return the identificador
     */
    public String getIdentificador() {
        return identificador;
    }
    
    /**
     * @param identificador the identificador to set
     */
    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion the descripcion to set
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * @return the sprints
     */
    public SprintsEntity getSprints() {
        return sprints;
    }

    /**
     * @param sprints the sprints to set
     */
    public void setSprints(SprintsEntity sprints) {
        this.sprints = sprints;
    }
    /**
     * @return the recursos
     */
    public String getRecursos() {
        return recursos;
    }

    /**
     * @param recursos the recursos to set
     */
    public void setRecursos(String recursos) {
        this.recursos = recursos;
    }

    /**
     * @return the colaborador
     */
    public ColaboradorEntity getColaborador() {
        return colaborador;
    }

    /**
     * @param colaborador the colaborador to set
     */
    public void setColaborador(ColaboradorEntity colaborador) {
        this.colaborador = colaborador;
    }

    /**
     * @return the fechaInicio
     */
    public Date getFechaInicio() {
        return fechaInicio;
    }

    /**
     * @param fechaInicio the fechaInicio to set
     */
    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    /**
     * @return the fechaCierre
     */
    public Date getFechaCierre() {
        return fechaCierre;
    }

    /**
     * @param fechaCierre the fechaCierre to set
     */
    public void setFechaCierre(Date fechaCierre) {
        this.fechaCierre = fechaCierre;
    }
    
}
