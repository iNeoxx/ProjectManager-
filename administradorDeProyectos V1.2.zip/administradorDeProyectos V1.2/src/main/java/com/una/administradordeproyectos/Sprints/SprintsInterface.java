/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Sprints;

import java.text.ParseException;
import java.util.Date;

/**
 *
 * @author antho
 */
public interface SprintsInterface {
    public String crear(String fecha, int num, Date[] fechas);
    public String[] buscar(String identificador);
    public String modificar();
    public String[] mostrarTodos();
    public String generarIdentificador(String proyId, int num);
    public Date[] verificarCrearFechas(String[] data) throws ParseException ;
    public String eliminar(String identificador);
}
