package com.una.administradordeproyectos.Colaborador;

import com.una.administradordeproyectos.Tareas.TareaContainer;
import com.una.administradordeproyectos.Tareas.TareaEntity;
import java.util.ArrayList;
import java.util.Collection;

/**
 * @author molin
 * @author hilde
 * @author antho
 */
public class ColaboradorController implements ColaboradorInterface {

    @Override
    public String crear(String[] data) {//Funcion crear recibe por parametro un array de datos de colaborador
        String respuesta = "Ya existe un colaborador con esa cedula";
        if (!ColaboradorContainer.existe(data[0])) {//Se verifica que no exista un colaborador con esa cedula
            ColaboradorEntity nColaborador = new ColaboradorEntity(data);//se crea el colaborador
            if (ColaboradorContainer.agregar(nColaborador)) {//Se llama la funcion add del contenedor y se manda por parametro para almacenar
                respuesta = "Colaborador agregado correctamente";
            } else {//Hubo un error
                respuesta = "Error al agregar al contenedor";
            }
        }
        return respuesta;
    }

    @Override
    public String modificar(String[] data, int opcion) {//recibe el nuevo dato a modificar
        //1=nombre,2=apellidos,3=telefono,4=email,5=especialidad,6=estado
        ColaboradorEntity colaborador = ColaboradorContainer.buscar(data[0]);
        if (opcion == 0) {
            colaborador.setNombre(data[1]);
            return "Se ha modificado el nombre correctamente";
        } else if (opcion == 1) {
            colaborador.setApellidos(data[1]);
            return "Se ha modificado el Apellido correctamente";
        } else if (opcion == 2) {
            colaborador.setTelefono(data[1]);
            return "Se ha modificado el Telefono correctamente";
        } else if (opcion == 3) {
            colaborador.setEmail(data[1]);
            return "Se ha modificado el Email correctamente";
        } else if (opcion == 4) {
            colaborador.setEspecialidad(data[1]);
            return "Se ha modificado la Especialidad correctamente";
        } else if (opcion == 5) {
            if (colaborador.getEstado() == false) {
                colaborador.setEstado(true);
            } else {
                colaborador.setEstado(false);
            }
            return "Se ha modificador el estado correctamente";
        }
        return "hubo un error al modificar el dato";
    }

    @Override
    public String[] find(String cedula) {
        ColaboradorEntity colaborador;
        if (ColaboradorContainer.existe(cedula)) {
            colaborador = ColaboradorContainer.buscar(cedula);
            if (colaborador.getEstado()) {
                String[] data = {"Cedula: " + colaborador.getCedula(), "Nombre: " + colaborador.getNombre() + " " + colaborador.getApellidos(), "Telefono: " + colaborador.getTelefono(), "Correo: " + colaborador.getEmail(), "Especialidad: " + colaborador.getEspecialidad(), "Estado: ACTIVO"};
                return data;
            } else {
                String[] data = {"Cedula: " + colaborador.getCedula(), "Nombre: " + colaborador.getNombre() + " " + colaborador.getApellidos(), "Telefono: " + colaborador.getTelefono(), "Correo: " + colaborador.getEmail(), "Especialidad: " + colaborador.getEspecialidad(), "Estado: INACTIVO"};
                return data;
            }
        }
        return null;
    }

    @Override
    public String eliminar(String cedula) {//Elimina un colaborador
        String respuesta = "No existe ningun colaborador con esa cedula";
        if (ColaboradorContainer.existe(cedula)) {//primero se verifica que exista el colaborador
            if (ColaboradorContainer.eliminar(cedula)) {//si existe lo elimina
                respuesta = "Colaborador eliminado correctamente";
            } else {//si no se elimina debe ser por algun error
                respuesta = "Error al eliminar al colaborador";
            }
        }

        return respuesta;
    }

    @Override
    public String[] mostrarTodos() {//Muestra todos los colaboradores
        if (ColaboradorContainer.mostrarTodos() != null) {
            Collection<ColaboradorEntity> colaboradores = ColaboradorContainer.mostrarTodos();
            String[] data = new String[colaboradores.size()];
            int i = 0;
            for (Object c : colaboradores) {
                ColaboradorEntity colaborador = (ColaboradorEntity) c;
                if (colaborador.getEstado() == false) {
                    data[i] = "Nombre: " + colaborador.getNombre() + " " + colaborador.getApellidos() + " Cedula: " + colaborador.getCedula() + " Estado: INACTIVO";
                } else {
                    data[i] = "Nombre: " + colaborador.getNombre() + " " + colaborador.getApellidos() + " Cedula: " + colaborador.getCedula() + " Estado: ACTIVO";
                }
                i++;
            }
            return data;
        }
        return null;
    }

    @Override
    public String[] mostrarTareasDeUnColaborador(String cedula) {//se recibe la cedula del colaborador
        ColaboradorEntity colaborador = ColaboradorContainer.buscar(cedula);
        if (ColaboradorContainer.existe(cedula)) {
            ArrayList cosa = colaborador.getTareas();
            if (!cosa.isEmpty()) {
                String data[] = new String[cosa.size()];
                int i = 0;
                for (Object c : cosa) {
                    TareaEntity tarea = (TareaEntity) c;
                    if (tarea != null) {
                        data[i] = "Identificador: " + tarea.getIdentificador() + "| Descripcion: " + tarea.getDescripcion() + "| Colaborador: " + tarea.getColaborador().getNombre() + " " + tarea.getColaborador().getApellidos() + "| Recursos: " + tarea.getRecursos()
                                + "| Fecha Inicio: " + tarea.getFechaInicio().getDate() + "/" + (tarea.getFechaInicio().getMonth() + 1) + "/" + (tarea.getFechaInicio().getYear() + 1900) + "| Fecha Cierre: " + tarea.getFechaCierre().getDate() + "/" + (tarea.getFechaCierre().getMonth() + 1) + "/" + (tarea.getFechaCierre().getYear() + 1900);
                        i++;
                    }
                }
                return data;
            }
        }
        return null;
    }
}
