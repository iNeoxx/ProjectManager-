package com.una.administradordeproyectos.Sprints;

import java.text.ParseException;
import java.util.Date;

/**
 * @author molin
 * @author hilde
 * @author antho
 */
public interface SprintsInterface {
    public String crear(String fecha, int num, Date[] fechas);
    public String[] buscar(String identificador);
    public String[] mostrarTodos();
    public String generarIdentificador(String proyId, int num);
    public Date[] verificarCrearFechas(String[] data) throws ParseException ;
    public String eliminar(String identificador);
    public String[] mostrarTareasDeUnSprint(String identificador);
}
