package com.una.administradordeproyectos.Sprints;

import com.una.administradordeproyectos.Proyecto.ProyectoContainer;
import com.una.administradordeproyectos.Tareas.TareaContainer;
import com.una.administradordeproyectos.Tareas.TareaEntity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

/**
 * @author molin
 * @author hilde
 * @author antho
 */
public class SprintsController implements SprintsInterface {

    @Override
    public String crear(String idProyecto, int num, Date[] fechas) { //Recibe los datos necesarios para crear el sprints
        String respuesta = "Sprint ya creado previamente";
        String sprintId = generarIdentificador(idProyecto, num);//Se genera el identificador
        if (!SprintsContainer.existe(sprintId)) {
            SprintsEntity nSprint = new SprintsEntity(sprintId, fechas);//Se manda al constructor el ID y las fechas
            if (SprintsContainer.agregar(nSprint)) {//Se llama la funcion agregar de container
                respuesta = "Sprint agregado correctamente";
                ProyectoContainer.buscar(idProyecto).setSprints(nSprint);//Se realiza la composicion entre proyecto y sprint
                nSprint.setProyecto(ProyectoContainer.buscar(idProyecto));
            } else {
                respuesta = "Error al agregar el sprint";
            }
        }
        return respuesta;
    }

    @Override
    public Date[] verificarCrearFechas(String[] data) throws ParseException {//Transforma las fechas que dijito el usuario a Date y verifica que coincida con el proyecto
        Date fechaInicioS = new SimpleDateFormat("dd/MM/yyyy").parse(data[1]);
        Date fechaFinalS = new SimpleDateFormat("dd/MM/yyyy").parse(data[2]);//Convierte un dato String a Date

        Date inicioProyecto = ProyectoContainer.buscar(data[0]).getFechaInicio();//Los se extrae las fechas de proyecto para compararlas con las de sprint
        Date finalProyecto = ProyectoContainer.buscar(data[0]).getFechaCierre();

        if (!fechaInicioS.before(inicioProyecto) && !fechaFinalS.after(finalProyecto)) {//Aca se verifica que correspondan las fechas
            Date[] fechas = {fechaInicioS, fechaFinalS};
            return fechas;
        }
        return null;
    }

    @Override
    public String generarIdentificador(String proyId, int num) {//Acá se genera el identificador de sprint
        String identificador;
        if (num < 10) {//Verifica que si el num es menor a 10 se le agrega un 0
            identificador = proyId + "-" + 0 + num;
        } else {
            identificador = proyId + "-" + num;
        }
        return identificador;
    }

    @Override
    public String[] buscar(String identificador) {//Funcion que retorna un Sprint
        if (SprintsContainer.existe(identificador)) {
            SprintsEntity sprint = SprintsContainer.buscar(identificador);
            String[] data = {"Identificador: " + sprint.getIdentificador(), "Fecha Inicio: " + sprint.getFechaInicio().getDate() + "/" + (sprint.getFechaInicio().getMonth() + 1) + "/" + (sprint.getFechaInicio().getYear() + 1900), "Fecha Cierre: " + (sprint.getFechaCierre().getDate() + 1) + "/" + (sprint.getFechaCierre().getMonth() + 1) + "/" + (sprint.getFechaCierre().getYear() + 1900)};
            return data;
        }
        return null;
    }

    @Override
    public String[] mostrarTodos() {
        if (SprintsContainer.mostrarTodos() != null) {
            Collection<SprintsEntity> sprints = SprintsContainer.mostrarTodos();//Se extrae una coleccion con todos los Sprints
            String[] data = new String[sprints.size()];
            int i = 0;
            for (Object c : sprints) {//Se recorre la coleccion
                SprintsEntity sprint = (SprintsEntity) c;
                data[i] = "Identificador: " + sprint.getIdentificador() + "| Fecha Inicio: " + sprint.getFechaInicio().getDate() + "/" + (sprint.getFechaInicio().getMonth() + 1) + "/" + (sprint.getFechaInicio().getYear() + 1900)
                        + "| Fecha Cierre: " + sprint.getFechaCierre().getDate() + "/" + (sprint.getFechaCierre().getMonth() + 1) + "/" + (sprint.getFechaCierre().getYear() + 1900);
                i++;
            }
            return data;
        }
        return null;
    }

    @Override
    public String eliminar(String identificador) {
        String respuesta = "No existe ningun Sprint con ese identificador";
        if (SprintsContainer.existe(identificador)) {
            ArrayList tareas = SprintsContainer.buscar(identificador).getTareas();//Se extrae las tareas del sprint
            if (tareas != null) {//Se verifica que tenga elementos
                for (Iterator it = tareas.iterator(); it.hasNext();) {//Se recorre el ArrayList
                    Object c = it.next();
                    TareaEntity tarea = (TareaEntity) c;
                    if (tarea != null) {
                        TareaContainer.eliminar(tarea);//se manda a llamar el eliminar de cada tarea para eliminarla 
                    }
                }
            }
            SprintsContainer.buscar(identificador).getProyecto().getSprints().remove(SprintsContainer.buscar(identificador));//Aca se elimina el sprint del arraylist de sprint de proycto
            SprintsContainer.eliminar(identificador);
            respuesta= "Se ha eliminado correctamente el Sprint";
        }
        return respuesta;
    }

    @Override
    public String[] mostrarTareasDeUnSprint(String identificador) {
        SprintsEntity sprint = SprintsContainer.buscar(identificador);//Se busca el sprint
        int i = 0;
        if (SprintsContainer.existe(identificador)) {
            ArrayList cosa = sprint.getTareas();//Se extrae el arraylist de tareas del sprint
            if (!cosa.isEmpty()) {
                String data[] = new String[cosa.size()];
                for (Object c : cosa) {//Se recorre el arraylist
                    TareaEntity tarea = (TareaEntity) c;
                    if (tarea.getColaborador() != null) {
                        data[i] = "Identificador: " + tarea.getIdentificador() + "| Descripcion: " + tarea.getDescripcion() + "| Colaborador: " + tarea.getColaborador().getNombre() + " " + tarea.getColaborador().getApellidos() + "| Recursos: " + tarea.getRecursos()
                                + "| Fecha Inicio: " + tarea.getFechaInicio().getDate() + "/" + (tarea.getFechaInicio().getMonth() + 1) + "/" + (tarea.getFechaInicio().getYear() + 1900) + "| Fecha Cierre: " + tarea.getFechaCierre().getDate() + "/" + (tarea.getFechaCierre().getMonth() + 1) + "/" + (tarea.getFechaCierre().getYear() + 1900);
                    } else {
                        data[i] = "Identificador: " + tarea.getIdentificador() + "| Descripcion: " + tarea.getDescripcion() + "| Colaborador: NO ASIGNADO " + "| Recursos: " + tarea.getRecursos() + "| Fecha Inicio: " + tarea.getFechaInicio().getDate() + "/" + (tarea.getFechaInicio().getMonth() + 1) + "/" + (tarea.getFechaInicio().getYear() + 1900)
                                + "| Fecha Cierre: " + tarea.getFechaCierre().getDate() + "/" + (tarea.getFechaCierre().getMonth() + 1) + "/" + (tarea.getFechaCierre().getYear() + 1900);
                    }
                    i++;
                }
                return data;
            }
        }
        return null;
    }
}
