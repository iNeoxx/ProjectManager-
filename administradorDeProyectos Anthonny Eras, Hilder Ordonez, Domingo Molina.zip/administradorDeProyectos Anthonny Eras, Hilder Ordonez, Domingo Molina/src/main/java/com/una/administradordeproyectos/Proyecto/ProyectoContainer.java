package com.una.administradordeproyectos.Proyecto;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.HashMap;

/**
 * @author molin
 * @author hilde
 * @author antho
 */
public class ProyectoContainer {

    //Key = identificador del proyecto
    private static Map<String, ProyectoEntity> cProyecto = new HashMap<String, ProyectoEntity>();

    public static boolean agregar(ProyectoEntity proyecto) {//Se agrega un elemento al HashMap
        if (!cProyecto.containsKey(proyecto.getIdentificador())) {
            cProyecto.put(proyecto.getIdentificador(), proyecto);//Se agrega al HashMap
            return true;
        }
        return false;
    }

    public static boolean existe(String identificador) {//Verifica que exista un elemento del HashMap
        if (cProyecto.containsKey(identificador)) {
            return true;
        }
        return false;
    }

    public static ProyectoEntity buscar(String identificador) {//Buscar un elemento del HashMap
        if (cProyecto.containsKey(identificador)) {
            ProyectoEntity proyecto = cProyecto.get(identificador);
            return proyecto;
        }
        return null;
    }

    public static boolean eliminar(String identificador) {//Eliminar un proyecto del HashMap
        if (cProyecto.containsKey(identificador)) {
            cProyecto.remove(identificador);//Se elimina del HashMap
            return true;
        }
        return false;
    }

    public static Collection<ProyectoEntity> mostrarTodos() {//Retorna el HashMap
        if (!cProyecto.isEmpty()) {
            Collection<ProyectoEntity> proyecto = cProyecto.values();//Aca se extrae la coleccion de proyectos
            return proyecto;
        }
        return null;
    }

}
