/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Sprints;

import com.una.administradordeproyectos.Proyecto.ProyectoContainer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

/**
 *
 * @author antho
 */
public class SprintsController implements SprintsInterface{
    
    @Override
    public String crear(String idProyecto, int num, Date[] fechas) throws ParseException { //arbusto denegado (flash + q)
        String respuesta = "Sprint ya creado previamente";
        String sprintId = generarIdentificador(idProyecto, num);  
            if(!SprintsContainer.existe(sprintId)){
                SprintsEntity nSprint = new SprintsEntity(sprintId, fechas);
                if(SprintsContainer.crear(nSprint)){
                    respuesta = "Sprint agregado al proyecto correctamente";
                    ProyectoContainer.buscar(idProyecto).setSprints(nSprint);
                    nSprint.setProyecto(ProyectoContainer.buscar(idProyecto));
                }
                else{
                    respuesta = "Error al agregar el sprint";
                }
        }
       return respuesta;
    }
    @Override
    public Date[] verificarCrearFechas(String[] data) throws ParseException {//Transforma las fechas que dijito el usuario a Date y verifica que coincida con el proyecto
        Date fechaInicioS = new SimpleDateFormat("dd/MM/yyyy").parse(data[1]);
        Date fechaFinalS = new SimpleDateFormat("dd/MM/yyyy").parse(data[2]);
        
        Date inicioProyecto = ProyectoContainer.buscar(data[0]).getFechaInicio();
        Date finalProyecto = ProyectoContainer.buscar(data[0]).getFechaCierre();
        
        if(!fechaInicioS.before(inicioProyecto) && !fechaFinalS.after(finalProyecto)){
            Date[] fechas = {fechaInicioS, fechaFinalS};
            return fechas;
        }
        return null;
    }
    @Override
    public String[] buscar(String identificador) {
       if(SprintsContainer.existe(identificador)){
            SprintsEntity sprint = SprintsContainer.buscar(identificador);
            String[] data = {"Identificador: "+sprint.getIdentificador(),"Fecha Inicio: " + sprint.getFechaInicio().getDate()+ "/" + (sprint.getFechaInicio().getMonth()+1) + "/" + (sprint.getFechaInicio().getYear() + 1900), "Fecha Cierre: " + (sprint.getFechaCierre().getDate()+1) + "/" + (sprint.getFechaCierre().getMonth()+1) + "/" + (sprint.getFechaCierre().getYear() + 1900)};
            return data;
        }
       return null;
    }
    
    @Override
    public String modificar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public String[] mostrarTodos() {
       if(SprintsContainer.mostrarTodos() != null){
           Collection<SprintsEntity> sprints = SprintsContainer.mostrarTodos();
           String []data = new String[sprints.size()];
           int i = 0;
           for(Object c:sprints){
               SprintsEntity sprint = (SprintsEntity)c;
               data[i] = "Identificador: "+sprint.getIdentificador() + " Fecha Inicio: " + sprint.getFechaInicio().getDate() + "/" + (sprint.getFechaInicio().getMonth()+1) + "/" + (sprint.getFechaInicio().getYear() + 1900) +
                       " Fecha Cierre: " + sprint.getFechaCierre().getDate() + "/" + (sprint.getFechaCierre().getMonth()+1) + "/" + (sprint.getFechaCierre().getYear() + 1900);
               i++;
           }
           return data;
       }
       return null;
    }
    @Override
    public String generarIdentificador(String proyId, int num){
      String identificador;
        if(num < 10){
            identificador = proyId + "-" + 0 + num;
        }else{
            identificador = proyId + "-" + num;
        }
        return identificador;
    }
}
