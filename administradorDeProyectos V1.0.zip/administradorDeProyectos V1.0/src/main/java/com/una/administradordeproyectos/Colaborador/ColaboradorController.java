/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Colaborador;

import java.util.Collection;

/**
 *
 * @author antho
 */
public class ColaboradorController implements ColaboradorInterface{

    @Override
    public String crear(String[] data) {//Funcion crear recibe por parametro un array de datos de colaborador
        String respuesta = "Ya existe un colaborador con esa cedula";
        if(!ColaboradorContainer.exist(data[0])){//Se verifica que no exista un colaborador con esa cedula
            ColaboradorEntity nColaborador = new ColaboradorEntity(data);//se crea el colaborador
            if(ColaboradorContainer.add(nColaborador)){//Se llama la funcion add del contenedor y se manda por parametro para almacenar
                respuesta = "Colaborador agregado correctamente";
            }else{//Hubo un error
                respuesta = "Error al agregar al contenedor";
            }
        }
        return respuesta;
    }

    @Override
    public String modificar(String[] data){//recibe los nuevos datos
        String answer = "No existen ningun colaborador con esa cedula";
        if(ColaboradorContainer.exist(data[0])){//verifica que exista ese colaborador para reemplazarlo
            ColaboradorEntity newColaborador = new ColaboradorEntity(data);//se crea
            if(ColaboradorContainer.update(newColaborador, data[0])){//se manda el colaborador nuevo junto a la cedula
                answer = "Colaborador reemplazado correctamente";
            }else{
                answer = "Error al reemplazar el colabolaborador";
            }
        }
        return answer;
    }

    @Override
    public String[] find(String cedula) {
        ColaboradorEntity colaborador;
        if(ColaboradorContainer.exist(cedula)){
            colaborador = ColaboradorContainer.find(cedula);
            if(colaborador.getEstado()){
                String []data = {"Cedula: "+colaborador.getCedula(), "Nombre: "+colaborador.getNombre()+" "+colaborador.getApellidos(), "Telefono: "+colaborador.getTelefono(), "Correo: "+colaborador.getEmail(), "Especialidad: "+colaborador.getEspecialidad(), "Estado: ACTIVO"};
                return data;
            }else{
                String []data = {"Cedula: "+colaborador.getCedula(), "Nombre: "+colaborador.getNombre()+" "+colaborador.getApellidos(), "Telefono: "+colaborador.getTelefono(), "Correo: "+colaborador.getEmail(), "Especialidad: "+colaborador.getEspecialidad(), "Estado: INACTIVO"};
                return data;
            }
        }
        return null;
    }

    @Override
    public String eliminar(String cedula) {
        String respuesta = "No existe ningun colaborador con esa cedula";
        if(ColaboradorContainer.exist(cedula)){//primero se verifica que exista el colaborador
             if(ColaboradorContainer.delete(cedula)){//si existe lo elimina
                respuesta = "Colaborador eliminado correctamente";
            }else{//si no se elimina debe ser por algun error
                respuesta = "Error al eliminar al colaborador";
            }
        }
        
        return respuesta;
    }

    @Override
    public String[] mostrarTodos() {
        if(ColaboradorContainer.getAll()!= null){
            Collection<ColaboradorEntity> colaboradores = ColaboradorContainer.getAll();
            String []data = new String[colaboradores.size()];
            int i = 0;
            for(Object c:colaboradores){
                 ColaboradorEntity colaborador = (ColaboradorEntity)c;
                 if(colaborador.getEstado()==false){
                    data[i] = "Nombre: "+colaborador.getNombre()+" "+colaborador.getApellidos()+" Cedula: "+colaborador.getCedula()+" Estado: INACTIVO";
                 }else{
                    data[i] = "Nombre: "+colaborador.getNombre()+" "+colaborador.getApellidos()+" Cedula: "+colaborador.getCedula()+" Estado: ACTIVO";
                 }
                    i++;
            }
            return data;
        }
        return null;
    }
    
}
