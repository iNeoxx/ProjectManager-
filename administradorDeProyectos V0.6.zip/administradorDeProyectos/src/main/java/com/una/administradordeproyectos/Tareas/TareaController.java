/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Tareas;

import com.una.administradordeproyectos.Colaborador.ColaboradorContainer;

/**
 *
 * @author antho
 */
public class TareaController implements TareaInterface{

    @Override
    public String crear(String[] data) {
       String respuesta = "Tarea ya creada previamente";
       if(!TareaContainer.existe(data[0])){
           TareaEntity nTarea = new TareaEntity(data);
           if(TareaContainer.agregar(nTarea)){
               respuesta = "Tarea agregada correctamente";
           }else{
               respuesta = "Error al agregar la tarea";
           }
       }
       return respuesta;
    }

    @Override
    public String modificar(String[] data) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    /**
     * 
     * @param data 0 = identificador, 1 = descripcion, 2 = nombreColaborador, 3 = recursos
     */
    public String[] buscar(String identificador) {
       TareaEntity tarea;
       if(TareaContainer.existe(identificador)){
           tarea = TareaContainer.buscar(identificador);
           String[] data = {tarea.getIdentificador(),tarea.getDescripcion(), tarea.getColaborador().getNombre(), tarea.getRecursos()};//Solo devuelve el nombre del colaborador
           return data;
       }
        return null;
    }

    @Override
    public String eliminar(String identificador) {
         String respuesta = "No existe ninguna tarea con ese identificador";
       if(TareaContainer.existe(identificador)){
           if(TareaContainer.delete(identificador)){
               respuesta = "Tarea Eliminada correctamente";
           }else{
               respuesta = "Error al eliminar la tarea";
           }
       }
        return respuesta;
    }

    @Override
    public String mostrarTodos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String agregarColaborador(String identificador, String cedula) {
      String respuesta = "Error al asignar el colaborador a tarea";
      if(TareaContainer.existe(identificador)){
          if(ColaboradorContainer.exist(cedula)){
              TareaContainer.agregarColaborador(identificador, ColaboradorContainer.find(cedula));
              respuesta = "Se ha asignado el colaborador";
          }
      }
        return respuesta;
    }
    
}
