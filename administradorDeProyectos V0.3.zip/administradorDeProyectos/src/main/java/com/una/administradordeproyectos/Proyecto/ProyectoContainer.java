/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Proyecto;

import java.util.Map;
import java.util.HashMap;
/**
 *
 * @author antho
 */
public class ProyectoContainer {
    //Key = identificador del proyecto
    private static Map<String,ProyectoEntity> eProyecto = new HashMap<String,ProyectoEntity>();
    //La KEY es el identificador?
}
