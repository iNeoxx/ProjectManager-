/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos;
//se importan los paquetes si no no funca
import com.una.administradordeproyectos.Colaborador.ColaboradorController;
import com.una.administradordeproyectos.Colaborador.ColaboradorInterface;
import com.una.administradordeproyectos.Proyecto.ProyectoContainer;
import com.una.administradordeproyectos.Proyecto.ProyectoController;
import com.una.administradordeproyectos.Proyecto.ProyectoInterface;
import com.una.administradordeproyectos.Sprints.SprintsController;
import com.una.administradordeproyectos.Sprints.SprintsInterface;
import com.una.administradordeproyectos.Tareas.TareaController;
import com.una.administradordeproyectos.Tareas.TareaInterface;
import java.text.ParseException;
import java.util.Date;

/**
 * @author molin
 * @author hilde
 * @author antho
 */
public class MainController {
    static int idProyecto = 1;//numero de id (ira aumentado)
    static int idSprints = 1;
    static int idTarea = 1; 
    static String letraP = "P";//letra de proyecto P
    //main
    public static void main(String[] args) throws ParseException { 
        int opcion;
        String respuesta;
        String menuOptions[] = {"Modulo Proyecto","Modulo Sprint","Modulo Tarea","Modulo Colaborador","Salir"};
        do{
            opcion = UI.menu("Menu Modulos",menuOptions);//Se crea el menu y se retorna la opcion que dijito el usuario
            switch(opcion){
                case 0://Modulo Proyecto
                    moduloProyecto();
                    break;
                case 1://Modulo Sprint
                    moduloSprints();
                    break;
                case 2://Modulo Tarea
                    moduloTarea();
                    break;
                case 3://Modulo Colaborador
                    moduloColaborador();
                    break;
                case 4://salir
                    UI.outLine("Saliendo del programa :)");
                    break;
                default:
                    UI.outLine("Digite una opcion valida");
                    break;
            }
        }while(opcion != 4);
    }
    //Modulos
    private static void moduloColaborador(){
        ColaboradorInterface colaborador = new ColaboradorController();//instancia de controlador
        int opcion;
        String identificador;
        String respuesta;
        String menuOptions[] = {"Crear","buscar","Modificar","Eliminar","Mostrar todos","Menu principal"};
        do{
            opcion = UI.menu("SubMenu Colaborador",menuOptions);//muestra el menu y retorna la opcion del usuario
            switch(opcion){
                case 0://Crear
                    String data[] = {"Cedula","Nombre","Apellidos","Telefono","Email","Especialidad"};
                    data = UI.input("Datos del Colaborador", data);
                    respuesta = colaborador.crear(data);//Create de controlador
                    UI.outLine(respuesta);//respuesta
                    break;
                case 1://Buscar
                    identificador = UI.input("Ingrese la cedula del colaborador");
                    String[] colaboradorData = colaborador.find(identificador);//se manda el identificador y retorna los datos del sprint
                   if(colaboradorData != null){
                       UI.outLine("------Datos del Colaborador almacenado------");
                       for(String line:colaboradorData){
                           UI.outLine(line);
                       }
                   }else{
                       UI.outLine("No existe ningun colaborador con esa cedula");
                   }
                    break;
                case 2://Modificar "revisar, esta manera es poco practico"
                    String data1[] = {"Cedula del colaborador a reemplazar","Nombre","Apellidos","Telefono","Email","Especialidad", "Estado"};
                    data1 = UI.input("Datos del nuevo colaborador", data1);
                    respuesta = colaborador.modificar(data1);
                    UI.outLine(respuesta);
                    break;
                case 3://Eliminar
                    identificador = UI.input("Ingrese la cedula del colaborador a eliminar");
                    respuesta = colaborador.eliminar(identificador);
                    UI.outLine(respuesta);
                    break;
                case 4://Mostrar Todos
                    String colaboradorLista[] = colaborador.mostrarTodos();
                    if(colaboradorLista != null){
                        UI.outLine("============Lista de Colaboradores============");
                        for(String line:colaboradorLista){
                            UI.outLine(line);
                        }
                        UI.outLine("==============================================");
                    }else{
                        UI.outLine("No existen colaboradores en el contenedor");
                    }
                    break;
                case 5:
                    UI.outLine("Volviendo al Menu Principal");
                    break;
                default:
                    UI.outLine("Digite una opcion valida");
                    break;
            }
        }while(opcion != 5);
        
    }
    private static void moduloTarea(){
        TareaInterface tarea = new TareaController();
        int opcion;
        String identificador;
        String respuesta;
        String menuOptions[] = {"Crear","buscar","Eliminar","Asignar Colaborador","Eliminar Colaborador","Mostrar todos","Menu principal"};
        do{
            opcion = UI.menu("Modulo Tarea",menuOptions);
            switch(opcion){
                case 0://Crear
                    String data[] = {"Identificador de Sprint","Descripcion","Recursos", "Fecha Inicio", "Fecha Cierre"};
                    data = UI.input("Datos de la Tarea", data);
                    respuesta = tarea.crear(data, idTarea);
                    idTarea++;
                    UI.outLine(respuesta);
                    break;
                case 1://buscar
                    identificador = UI.input("Ingrese el identificador de tarea a consultar");
                    String tareaData[]=tarea.buscar(identificador);
                    if(tareaData!=null){
                        UI.outLine("=======Datos de la tarea alamacenada========");
                        for(String line:tareaData){
                            UI.outLine(line);
                        }
                    }else{
                        UI.outLine("No existe ninguna tarea con ese identificador");
                    }
                    break;
                case 2://Eliminar
                    identificador = UI.input("Ingrese el identificador de la tarea a eliminar");
                    respuesta = tarea.eliminar(identificador);
                    UI.outLine(respuesta);
                    break;
                case 3://Asignar Colaborador
                    identificador = UI.input("Ingrese el identificador de tarea");
                    String cedula = UI.input("Ingrese la cedula del colaborador");
                    respuesta = tarea.agregarColaborador(identificador, cedula);
                    UI.outLine(respuesta);
                    break;
                case 4://Eliminar Colaborador
                    identificador = UI.input("Ingrese el identificador de tarea");
                    respuesta = tarea.eliminarColaborador(identificador);
                    UI.outLine(respuesta);
                    break;
                case 5://Mostrat todos
                    String tareaLista[] = tarea.mostrarTodos();
                    if(tareaLista != null){
                        UI.outLine("============Lista de Tareas============");
                        for(String line:tareaLista){
                            UI.outLine(line);
                        }
                        UI.outLine("==============================================");
                    }else{
                        UI.outLine("No existen Tareas en el contenedor");
                    }
                    break;
                case 6:
                    UI.outLine("Volviendo al menu principal");
                    break;
                default:
                    UI.outLine("Opcion no valida");
                    break;
            }
        }while(opcion != 6);
    }
    private static void moduloProyecto() throws ParseException{
        ProyectoInterface proyecto = new ProyectoController();
        int opcion;
        String identificador;
        String respuesta;
        String menuOptions[] = {"Crear","buscar","Eliminar","Mostrar todos","Mostrar Sprints de un proyecto","Menu principal"};
        do{
            opcion = UI.menu("MODULO PROYECTO", menuOptions);
            switch(opcion){
                case 0://crear 
                    String data[] = {"Nombre del proyecto", "Fecha de Inicio", "Fecha Final"};
                    data = UI.input("Datos del proyecto", data);
                    respuesta = proyecto.crear(data,proyecto.generarIdentificador(letraP, idProyecto));
                    idProyecto += 1;
                    UI.outLine(respuesta);
                    break;
                case 1://buscar
                    identificador = UI.input("Ingrese el identificador del proyecto a consultar");
                    String proyectoData[] = proyecto.buscar(identificador);
                    if(proyectoData!=null){
                        UI.outLine("=======Datos del proyecto========");
                        for(String line:proyectoData){
                            UI.outLine(line);
                                    
                        }
                    }else{
                        UI.outLine("No existe ningun proyecto con ese identificador");
                    } 
                    break;
                case 2://eliminar
                    identificador = UI.input("Ingrese el identificador del proyecto");
                    respuesta = proyecto.eliminar(identificador);
                    UI.outLine(respuesta);
                    break;
                case 3://mostrar todos
                    String[] proyectoLista = proyecto.mostrarTodos();
                    if(proyectoLista != null){
                        UI.outLine("============Lista de proyectos============");
                        for(String line:proyectoLista){
                            UI.outLine(line);
                        }
                        UI.outLine("==============================================");
                    }else{
                        UI.outLine("No existen proyectos en el contenedor");
                    }
                    break;

                case 4: //mostrar sprints de un proyecto
                    identificador = UI.input("Digite el identificador del proyecto:");
                    String[]sprintLista = proyecto.mostrarSprintsDeUnProyecto(identificador);
                    if(sprintLista != null){
                        UI.outLine("Sprints del proyecto" + identificador + ": ");
                        for(String line:sprintLista){
                          UI.outLine(line);  
                        }
                        UI.outLine("==============================================");
                    }
                    else{
                        UI.outLine("No existen Sprints en ese proyecto o el identificador no es valido");
                    }
                    break;
                case 5: //salir
                    UI.outLine("Volviendo al menu principal");
                    break; 
                default:
                    UI.outLine("Digite una opcion valida");
                    break;
            }
        }while(opcion != 5);
    }
    private static void moduloSprints() throws ParseException{
        SprintsInterface sprint = new SprintsController();//instancia de controlador
        int opcion;
        String respuesta;
        String menuOptions[] = {"Crear","buscar","Modificar","Eliminar","Mostrar todos","Menu principal"};
        String identificador;
        do{
            opcion = UI.menu("SubMenu Sprints",menuOptions);//muestra el menu y retorna la opcion del usuario
            switch(opcion){
                case 0://Crear
                    String data[] = {"Identificador del proyecto", "Fecha de Inicio", "Fecha Final"};
                    data = UI.input("Datos del Sprint", data);
                    if(ProyectoContainer.existe(data[0])){
                        Date[] fechas = sprint.verificarCrearFechas(data);
                        if(fechas != null){
                            respuesta = sprint.crear(data[0], idSprints, fechas);//Create de controlador
                            UI.outLine(respuesta);//respuesta
                            idSprints ++;
                            UI.outLine(respuesta);
                            break;
                        }else{
                            UI.outLine("Las fechas que ha ingresado no coinciden con las de proyecto");
                            break;
                        }
                    }else{
                        UI.outLine("No existe ningun proyecto con ese Identificador");
                    }
                    break;
                case 1://Buscar
                    identificador = UI.input("Ingrese el identificador de Sprint");
                    String[] sprintData = sprint.buscar(identificador);//se manda el identificador y retorna los datos del sprint
                   if(sprintData != null){
                       UI.outLine("------Datos del Sprint almacenado------");
                       for(String line:sprintData){
                           UI.outLine(line);
                       }
                   }else{
                       UI.outLine("No existe ningun Sprint con ese identificador");
                   }
                    break;
                case 2://Modificar "revisar, esta manera es poco practico"
                    /*String data1[] = {"Cedula del colaborador a reemplazar","Nombre","Apellidos","Telefono","Email","Especialidad", "Estado"};
                    data1 = UI.input("Datos del nuevo colaborador", data1);
                    respuesta = sprint.modificar(data1);
                    UI.outLine(respuesta);*/
                    break;
                case 3://Eliminar
                    /*identificador = UI.input("Ingrese la cedula del colaborador a eliminar");
                    respuesta = sprint.eliminar(identificador);
                    UI.outLine(respuesta);*/
                    break;
                case 4://Mostrar Todos
                    String colaboradorLista[] = sprint.mostrarTodos(); 
                    if(colaboradorLista != null){
                        UI.outLine("============Lista de Sprints============");
                        for(String line:colaboradorLista){
                            UI.outLine(line);
                        }
                        UI.outLine("==============================================");
                    }else{
                        UI.outLine("No existen Sprints en el contenedor");
                    }
                    break;
                case 5:
                    UI.outLine("Volviendo al Menu Principal");
                    break;
                default:
                    UI.outLine("Digite una opcion valida");
                    break;
            }
        }while(opcion != 5);
        
    }
}
