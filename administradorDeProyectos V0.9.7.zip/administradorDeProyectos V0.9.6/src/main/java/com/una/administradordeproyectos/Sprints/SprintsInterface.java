/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Sprints;

import java.text.ParseException;
import java.util.Date;

/**
 *
 * @author antho
 */
public interface SprintsInterface {
    public String crear(String fecha[], int num) throws ParseException ;
    public String[] buscar(String identificador);
    public String modificar();
    public String[] mostrarTodos();
    public String generarIdentificador(String proyId, int num);
    //public String eliminar();
}
