/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.administradordeproyectos.Sprints;

import com.una.administradordeproyectos.Tareas.TareaEntity;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author antho
 */
public class SprintsEntity {
    private String identificador;
    private Date fechaInicio;
    private Date fechaCierre;
    private ArrayList<TareaEntity> tareas;
    
    public SprintsEntity(String identificador, Date fechaI, Date fechaF){
        this.identificador = identificador; 
        this.fechaInicio = fechaI; 
        this.fechaCierre = fechaF;
        this.tareas = new ArrayList();
        
    }

    /**
     * @return the identificador
     */
    public String getIdentificador() {
        return identificador;
    }

    /**
     * @param identificador the identificador to set
     */
    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    /**
     * @return the fechaInicio
     */
    public Date getFechaInicio() {
        return fechaInicio;
    }

    /**
     * @param fechaInicio the fechaInicio to set
     */
    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    /**
     * @return the fechaCierre
     */
    public Date getFechaCierre() {
        return fechaCierre;
    }

    /**
     * @param fechaCierre the fechaCierre to set
     */
    public void setFechaCierre(Date fechaCierre) {
        this.fechaCierre = fechaCierre;
    }

    /**
     * @return the tareas
     */
    public ArrayList<TareaEntity> getTareas() {
        return tareas;
    }

    /**
     * @param cantidadTarea the tareas to set
     */
    public void setTarea(ArrayList<TareaEntity> cantidadTarea) {
        this.tareas = cantidadTarea;
    }
    
}
