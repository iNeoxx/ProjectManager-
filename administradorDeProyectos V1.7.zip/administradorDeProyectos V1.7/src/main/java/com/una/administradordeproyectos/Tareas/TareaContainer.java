package com.una.administradordeproyectos.Tareas;

import com.una.administradordeproyectos.Colaborador.ColaboradorEntity;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * @author molin
 * @author hilde
 * @author antho
 */
public class TareaContainer {
    private static Map<String,TareaEntity> cTarea = new HashMap<String,TareaEntity>();
     //KEY es identificador de Tarea
    public static boolean agregar(TareaEntity tarea){
        if(!cTarea.containsKey(tarea.getIdentificador())){
            cTarea.put(tarea.getIdentificador(), tarea);
            return true;
        }
        return false;
    }
    public static boolean existe(String identificador){
        if(cTarea.containsKey(identificador)){
            return true;
        }
        return false;
    }
    public static TareaEntity buscar(String identificador){//Problema con el buscar de colaborador, al mostrar el colaborador y no se ha asignado será null y no se puede meter un nul en un array(chashea)
        TareaEntity tarea;
        if(cTarea.containsKey(identificador)){
            tarea = cTarea.get(identificador);
            return tarea;
        }
        return null;
    }
    public static boolean actualizar(){
        return false;
    }
    public static boolean eliminar(String identificador){
        if(cTarea.containsKey(identificador)){
            cTarea.remove(identificador);
            return true;
        }
        return false;
    }
    public static boolean agregarColaborador(String identificador, ColaboradorEntity colaborador){
        if(cTarea.containsKey(identificador)){
            cTarea.get(identificador).setColaborador(colaborador); //se setea en tarea el colaborador
            colaborador.setTareas(cTarea.get(identificador));//se setea en colaborador la tarea (bidireccional)
            colaborador.setEstado(true);
            return true;
        }
        return false;
    }
    public static boolean eliminarColaborador(String identificador){
        if(cTarea.containsKey(identificador)){
            cTarea.get(identificador).setColaborador(null);
            return true;
        }
        return false;
    }
    public static Collection<TareaEntity> mostrarTodos(){
         Collection<TareaEntity> tareas = cTarea.values();
        if(!cTarea.isEmpty()){
            return tareas;
        }
        return null;
    }
}
