package com.una.administradordeproyectos.Proyecto;

import com.una.administradordeproyectos.Sprints.SprintsEntity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * @author molin
 * @author hilde
 * @author antho
 */
public class ProyectoController implements ProyectoInterface {

    @Override
    public String crear(String[] data, String identificador) throws ParseException {
        String respuesta = "Ya existe un proyecto con esa identificador";
        if (!ProyectoContainer.existe(data[0])) {
            Date fechaInicio = new SimpleDateFormat("dd/MM/yyyy").parse(data[1]);
            Date fechaFinal = new SimpleDateFormat("dd/MM/yyyy").parse(data[2]);
            ProyectoEntity nProyecto = new ProyectoEntity(data[0], fechaInicio, fechaFinal, identificador);
            if (ProyectoContainer.agregar(nProyecto)) {
                respuesta = "Proyecto agregado correctamente";
            } else {
                respuesta = "Error al agregar al contenedor";
            }
        }
        return respuesta;
    }

    @Override
    public String generarIdentificador(String p, int numero) {
        String identificador;
        if (numero < 10) {
            identificador = p + 0 + numero;
        } else {
            identificador = p + numero;
        }
        return identificador;
    }

    @Override
    public String modificar(String[] data1) {
        if(ProyectoContainer.existe(data1[0])){
            ProyectoContainer.buscar(data1[0]).setNombreProyecto(data1[1]);
            return "Se ha modificador el nombre correctamente";
        }
        return "No existe ningun proyecto con ese identificador";
    }

    @Override
    public String[] buscar(String identificador) {
        if (ProyectoContainer.existe(identificador)) {
            ProyectoEntity proyecto = ProyectoContainer.buscar(identificador);
            String[] data = {"Identificador: " + proyecto.getIdentificador(), "Nombre del Proyecto: " + proyecto.getNombreProyecto(), "Fecha Inicio: " + proyecto.getFechaInicio().getDate() + "/" + (proyecto.getFechaInicio().getMonth() + 1) + "/" + (proyecto.getFechaInicio().getYear() + 1900) + " Fecha Cierre: " + proyecto.getFechaCierre().getDate() + "/" + (proyecto.getFechaCierre().getMonth() + 1) + "/" + (proyecto.getFechaCierre().getYear() + 1900)};
            return data;
        }
        return null;
    }

    @Override
    public String eliminar(String identificador) {
        String respuesta = "No existe ningun proyecto con ese identificador";
        if (ProyectoContainer.existe(identificador)) {
            if (ProyectoContainer.eliminar(identificador)) {
                respuesta = "Proyecto Elimnado correctamente";
            } else {
                respuesta = "Error al eliminar el proyecto";
            }
        }
        return respuesta;
    }

    @Override
    public String[] mostrarTodos() {
        if (ProyectoContainer.mostrarTodos() != null) {
            Collection<ProyectoEntity> proyectos = ProyectoContainer.mostrarTodos();
            String[] data = new String[proyectos.size()];
            int i = 0;
            for (Object c : proyectos) {
                ProyectoEntity proyecto = (ProyectoEntity) c;
                data[i] = "Identificador: " + proyecto.getIdentificador() + "| Nombre del proyecto: " + proyecto.getNombreProyecto() + " | Fecha Inicio: " + proyecto.getFechaInicio().getDate() + "/" + (proyecto.getFechaInicio().getMonth() + 1) + "/" + (proyecto.getFechaInicio().getYear() + 1900)
                        + " | Fecha Cierre: " + proyecto.getFechaCierre().getDate() + "/" + (proyecto.getFechaCierre().getMonth() + 1) + "/" + (proyecto.getFechaCierre().getYear() + 1900);
                i++;
            }
            return data;
        }
        return null;
    }

    @Override
    public String[] mostrarSprintsDeUnProyecto(String proyId) {
        ProyectoEntity projectt = ProyectoContainer.buscar(proyId);
        if (ProyectoContainer.existe(proyId)) {
            ArrayList cosa = projectt.getSprints();
            if (!cosa.isEmpty()) {
                String data[] = new String[cosa.size()];
                int i = 0;
                for (Object c : cosa) {
                    SprintsEntity sprint = (SprintsEntity) c;
                    data[i] = "Identificador: " + sprint.getIdentificador() + " Fecha Inicio: " + sprint.getFechaInicio().getDay() + "/" + sprint.getFechaInicio().getMonth() + "/" + (sprint.getFechaInicio().getYear() + 1900) + " Fecha Cierre: " + sprint.getFechaCierre().getDay() + "/" + sprint.getFechaCierre().getMonth() + "/" + (sprint.getFechaCierre().getYear() + 1900);
                    i++;
                }
                return data;
            }
        }
        return null;
    }
}
